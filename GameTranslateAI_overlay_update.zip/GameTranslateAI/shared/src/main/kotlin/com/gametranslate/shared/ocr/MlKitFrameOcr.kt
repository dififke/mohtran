package com.gametranslate.shared.ocr

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import com.gametranslate.shared.core.FrameOcr
import com.gametranslate.shared.model.RegionPreset
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream

/**
 * OCR عبر Google ML Kit (النموذج المدمج، يعمل بدون إنترنت، يدعم الحروف اللاتينية).
 * يقتطع منطقة النص المحددة قبل القراءة لتقليل الزمن، ويعيد كتلة نصية لكل مقطع.
 */
class MlKitFrameOcr : FrameOcr {
    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

    override suspend fun recognize(image: ByteArray, region: RegionPreset): List<String> {
        val bitmap = withContext(Dispatchers.Default) { decodeAndCrop(image, region) }
            ?: return emptyList()
        val result = recognizer.process(InputImage.fromBitmap(bitmap, 0)).await()
        return result.textBlocks
            .sortedWith(compareBy({ it.boundingBox?.top ?: 0 }, { it.boundingBox?.left ?: 0 }))
            .map { it.text.replace('\n', ' ').trim() }
            .filter { it.isNotEmpty() }
    }

    private fun decodeAndCrop(bytes: ByteArray, region: RegionPreset): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        if (bounds.outWidth <= 0) return null
        var sample = 1
        while (bounds.outWidth / sample > 2000) sample *= 2
        val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = sample })
            ?: return null
        if (region == RegionPreset.FULL) return bmp
        val y = (bmp.height * region.top).toInt().coerceIn(0, bmp.height - 1)
        val h = (bmp.height * (region.bottom - region.top)).toInt().coerceIn(1, bmp.height - y)
        return Bitmap.createBitmap(bmp, 0, y, bmp.width, h)
    }

    fun close() = recognizer.close()
}

/** يرسم صورة تجريبية تشبه لقطة لعبة (نص إنجليزي) لاختبار OCR فعلياً دون الحاجة إلى PS5. */
object DemoFrames {
    fun render(lines: List<String>): ByteArray {
        val w = 1280
        val h = 720
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val bg = Paint().apply { shader = LinearGradient(0f, 0f, 0f, h.toFloat(), Color.rgb(20, 20, 40), Color.rgb(5, 5, 10), Shader.TileMode.CLAMP) }
        c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), bg)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textSize = 54f; typeface = android.graphics.Typeface.DEFAULT_BOLD }
        var y = h - 80f - (lines.size - 1) * 90f
        for (line in lines) {
            c.drawText(line, 80f, y, paint)
            y += 90f
        }
        val out = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.PNG, 100, out)
        return out.toByteArray()
    }
}

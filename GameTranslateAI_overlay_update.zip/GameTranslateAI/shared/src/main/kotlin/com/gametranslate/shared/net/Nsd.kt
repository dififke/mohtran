package com.gametranslate.shared.net

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo

data class DiscoveredTv(val name: String, val host: String, val port: Int)

object Nsd {
    const val SERVICE_TYPE = "_gametranslate._tcp."

    /** يعلن التلفاز عن نفسه على الشبكة المحلية كي يجده الهاتف تلقائياً. */
    class Registration(context: Context, private val name: String, private val port: Int) {
        private val manager = context.applicationContext.getSystemService(Context.NSD_SERVICE) as NsdManager
        private var listener: NsdManager.RegistrationListener? = null

        fun register() {
            if (listener != null) return
            val info = NsdServiceInfo().apply {
                serviceName = name
                serviceType = SERVICE_TYPE
                port = this@Registration.port
            }
            val l = object : NsdManager.RegistrationListener {
                override fun onServiceRegistered(i: NsdServiceInfo) {}
                override fun onRegistrationFailed(i: NsdServiceInfo, code: Int) {}
                override fun onServiceUnregistered(i: NsdServiceInfo) {}
                override fun onUnregistrationFailed(i: NsdServiceInfo, code: Int) {}
            }
            listener = l
            runCatching { manager.registerService(info, NsdManager.PROTOCOL_DNS_SD, l) }
        }

        fun unregister() {
            listener?.let { runCatching { manager.unregisterService(it) } }
            listener = null
        }
    }

    /** يبحث عن أجهزة تلفاز تعمل بالتطبيق. يحلّ العناوين واحداً تلو الآخر لتفادي أخطاء NsdManager. */
    class Discovery(
        context: Context,
        private val onFound: (DiscoveredTv) -> Unit,
        private val onLost: (String) -> Unit
    ) {
        private val manager = context.applicationContext.getSystemService(Context.NSD_SERVICE) as NsdManager
        private var listener: NsdManager.DiscoveryListener? = null
        private val queue = ArrayDeque<NsdServiceInfo>()
        private var resolving = false

        @Synchronized
        private fun enqueue(info: NsdServiceInfo) {
            queue.addLast(info)
            next()
        }

        @Synchronized
        private fun next() {
            if (resolving) return
            val info = queue.removeFirstOrNull() ?: return
            resolving = true
            runCatching {
                manager.resolveService(info, object : NsdManager.ResolveListener {
                    override fun onResolveFailed(i: NsdServiceInfo, code: Int) { done() }
                    override fun onServiceResolved(i: NsdServiceInfo) {
                        val host = i.host?.hostAddress
                        if (host != null) onFound(DiscoveredTv(i.serviceName, host, i.port))
                        done()
                    }
                })
            }.onFailure { done() }
        }

        @Synchronized private fun done() { resolving = false; next() }

        fun start() {
            if (listener != null) return
            val l = object : NsdManager.DiscoveryListener {
                override fun onDiscoveryStarted(t: String) {}
                override fun onDiscoveryStopped(t: String) {}
                override fun onStartDiscoveryFailed(t: String, code: Int) {}
                override fun onStopDiscoveryFailed(t: String, code: Int) {}
                override fun onServiceFound(i: NsdServiceInfo) { enqueue(i) }
                override fun onServiceLost(i: NsdServiceInfo) { onLost(i.serviceName) }
            }
            listener = l
            runCatching { manager.discoverServices(SERVICE_TYPE, NsdManager.PROTOCOL_DNS_SD, l) }
        }

        fun stop() {
            listener?.let { runCatching { manager.stopServiceDiscovery(it) } }
            listener = null
            synchronized(this) { queue.clear(); resolving = false }
        }
    }
}

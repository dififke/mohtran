package com.gametranslate.shared.model

import kotlinx.serialization.Serializable

const val DEFAULT_PORT = 8765
const val APP_VERSION = "1.0.0"

@Serializable enum class ProviderType { DEMO, GEMINI, OPENAI }
@Serializable enum class SubtitlePosition { TOP, CENTER, BOTTOM }

/** منطقة الشاشة التي يقرأها OCR (نسبة من ارتفاع الصورة). اقتصاص المنطقة يسرّع المعالجة. */
@Serializable
enum class RegionPreset(val top: Float, val bottom: Float) {
    FULL(0f, 1f), BOTTOM_THIRD(0.66f, 1f), BOTTOM_HALF(0.5f, 1f), TOP_HALF(0f, 0.5f)
}

@Serializable
data class AppSettings(
    val sourceLang: String = "en",
    val targetLang: String = "ar",
    val provider: ProviderType = ProviderType.DEMO,
    val geminiModel: String = "gemini-2.5-flash",
    val openAiBaseUrl: String = "https://api.openai.com/v1",
    val openAiModel: String = "gpt-4o-mini",
    val fontSizeSp: Int = 30,
    val textColor: Long = 0xFFFFFFFF,
    val backgroundColor: Long = 0xFF000000,
    val backgroundOpacity: Float = 0.6f,
    val position: SubtitlePosition = SubtitlePosition.BOTTOM,
    val captureIntervalMs: Long = 700,
    val region: RegionPreset = RegionPreset.FULL,
    val glossary: String = ""
)

@Serializable
data class TranslationItem(
    val source: String,
    val translated: String,
    val fromCache: Boolean = false,
    val timestamp: Long = 0,
    val pair: String = ""
)

@Serializable
data class Metrics(
    val ocrMs: Long = 0,
    val translateMs: Long = 0,
    val totalMs: Long = 0,
    val lines: Int = 0,
    val cacheHits: Int = 0
)

@Serializable
data class EngineStatus(
    val running: Boolean,
    val paused: Boolean,
    val provider: ProviderType,
    val hasApiKey: Boolean,
    val lastError: String? = null,
    val notice: String? = null,
    val metrics: Metrics = Metrics(),
    val subtitle: String = "",
    val deviceName: String = "",
    val version: String = APP_VERSION
)

@Serializable data class CommandRequest(val action: String)
@Serializable data class TextSubmission(val lines: List<String>)
@Serializable data class KeysUpdate(val geminiKey: String? = null, val openAiKey: String? = null)
@Serializable data class PingResponse(val name: String, val app: String = "GameTranslateAI", val version: String = APP_VERSION)

@Serializable
data class SimpleResult(
    val ok: Boolean,
    val message: String = "",
    val subtitle: String? = null,
    val metrics: Metrics? = null
)

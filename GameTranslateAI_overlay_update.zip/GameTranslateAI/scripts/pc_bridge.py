#!/usr/bin/env python3
"""
جسر الكمبيوتر -> التلفاز  (مسار PS5 العملي عبر PS Remote Play)

1) شغّل PS Remote Play على الكمبيوتر وافتح اللعبة.
2) شغّل هذا السكربت: يلتقط منطقة من الشاشة كل فترة ويرسلها إلى تطبيق التلفاز.
3) التلفاز يقرأ النص (OCR) ويترجمه ويعرضه. ويظهر نفس الترجمة هنا فوق الشاشة (نافذة شفافة).

مثال:
  python pc_bridge.py --tv 192.168.1.50 --pin 123456 --region bottom-third
  python pc_bridge.py --tv 192.168.1.50 --pin 123456 --box 0,700,1920,380 --interval 0.7
"""
import argparse, io, sys, time, threading, queue

try:
    import mss, requests
    from PIL import Image
except ImportError:
    sys.exit("ثبّت المتطلبات أولاً:  pip install -r requirements.txt")

REGIONS = {"full": (0.0, 1.0), "bottom-third": (0.66, 1.0), "bottom-half": (0.5, 1.0), "top-half": (0.0, 0.5)}


def grab(sct, monitor, box):
    if box:
        x, y, w, h = box
        mon = {"left": monitor["left"] + x, "top": monitor["top"] + y, "width": w, "height": h}
    else:
        mon = monitor
    shot = sct.grab(mon)
    return Image.frombytes("RGB", shot.size, shot.rgb)


def send_loop(args, out_q, stop):
    url = f"http://{args.tv}:{args.port}/api/frame"
    headers = {"X-Token": args.pin, "Content-Type": "application/octet-stream"}
    with mss.mss() as sct:
        monitor = sct.monitors[args.monitor]
        box = tuple(int(v) for v in args.box.split(",")) if args.box else None
        while not stop.is_set():
            t0 = time.time()
            img = grab(sct, monitor, box)
            if args.max_width and img.width > args.max_width:
                img = img.resize((args.max_width, int(img.height * args.max_width / img.width)))
            buf = io.BytesIO()
            img.save(buf, "JPEG", quality=85)
            try:
                r = requests.post(url, data=buf.getvalue(), headers=headers, timeout=30)
                if r.status_code == 401:
                    out_q.put(("error", "رمز PIN غير صحيح")); break
                data = r.json()
                if data.get("subtitle"):
                    m = data.get("metrics") or {}
                    print(f"[{m.get('totalMs','?')}ms] {data['subtitle']}")
                    out_q.put(("sub", data["subtitle"]))
                elif not data.get("ok"):
                    print("تنبيه:", data.get("message"))
            except requests.RequestException as e:
                out_q.put(("error", f"تعذر الوصول للتلفاز: {e.__class__.__name__}"))
                time.sleep(2)
            time.sleep(max(0.0, args.interval - (time.time() - t0)))


def run_overlay(out_q, stop):
    import tkinter as tk
    root = tk.Tk()
    root.overrideredirect(True)
    root.attributes("-topmost", True)
    try:
        root.attributes("-alpha", 0.85)
    except tk.TclError:
        pass
    root.configure(bg="black")
    label = tk.Label(root, text="بانتظار النص...", fg="white", bg="black", font=("Segoe UI", 26, "bold"), wraplength=1400, justify="center")
    label.pack(padx=24, pady=12)
    sw, sh = root.winfo_screenwidth(), root.winfo_screenheight()
    root.geometry(f"+{sw // 2 - 400}+{sh - 220}")
    root.bind("<Escape>", lambda e: (stop.set(), root.destroy()))
    root.bind("<Button-1>", lambda e: setattr(root, "_drag", (e.x_root - root.winfo_x(), e.y_root - root.winfo_y())))
    root.bind("<B1-Motion>", lambda e: root.geometry(f"+{e.x_root - root._drag[0]}+{e.y_root - root._drag[1]}"))

    def poll():
        try:
            while True:
                kind, text = out_q.get_nowait()
                label.config(text=text if kind == "sub" else "⚠ " + text)
        except queue.Empty:
            pass
        if not stop.is_set():
            root.after(100, poll)
    poll()
    root.mainloop()


def main():
    ap = argparse.ArgumentParser(description="التقاط شاشة PS Remote Play وإرسالها إلى تطبيق GameTranslate على التلفاز")
    ap.add_argument("--tv", required=True, help="عنوان IP للتلفاز (يظهر في شاشة الاتصال)")
    ap.add_argument("--pin", required=True, help="رمز الاقتران من التلفاز")
    ap.add_argument("--port", type=int, default=8765)
    ap.add_argument("--monitor", type=int, default=1, help="رقم الشاشة (1 = الرئيسية)")
    ap.add_argument("--box", help="منطقة الالتقاط x,y,w,h بالبكسل (نسبة لزاوية الشاشة)")
    ap.add_argument("--region", choices=list(REGIONS), help="إعداد التلفاز يتحكم بالمنطقة أيضاً؛ هذا خيار للالتقاط المحلي فقط")
    ap.add_argument("--interval", type=float, default=0.7, help="الفاصل بين اللقطات بالثواني")
    ap.add_argument("--max-width", type=int, default=1600, help="تصغير العرض لتسريع الإرسال (0 = بدون)")
    ap.add_argument("--no-overlay", action="store_true", help="عدم عرض نافذة الترجمة فوق الشاشة")
    args = ap.parse_args()

    if args.region and not args.box:
        with mss.mss() as sct:
            m = sct.monitors[args.monitor]
        top, bottom = REGIONS[args.region]
        args.box = f"0,{int(m['height'] * top)},{m['width']},{int(m['height'] * (bottom - top))}"

    # تأكد أن التلفاز يعمل
    try:
        p = requests.get(f"http://{args.tv}:{args.port}/api/ping", timeout=5).json()
        print("متصل بـ:", p.get("name"))
        print("ملاحظة: يجب الضغط على 'بدء الترجمة' في التلفاز أو الهاتف، وإلا ستُرفض الإطارات.")
    except requests.RequestException:
        sys.exit("تعذر الوصول للتلفاز. تحقق من العنوان والمنفذ وأن التطبيق مفتوح.")

    q, stop = queue.Queue(), threading.Event()
    t = threading.Thread(target=send_loop, args=(args, q, stop), daemon=True)
    t.start()
    try:
        if args.no_overlay:
            while t.is_alive():
                time.sleep(0.5)
        else:
            run_overlay(q, stop)
    except KeyboardInterrupt:
        pass
    finally:
        stop.set()


if __name__ == "__main__":
    main()

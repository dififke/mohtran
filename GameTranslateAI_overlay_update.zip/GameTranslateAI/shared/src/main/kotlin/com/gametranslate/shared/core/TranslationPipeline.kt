package com.gametranslate.shared.core

import com.gametranslate.shared.model.AppSettings
import com.gametranslate.shared.model.Metrics
import com.gametranslate.shared.model.TranslationItem
import com.gametranslate.shared.translate.TranslationProvider
import com.gametranslate.shared.translate.TranslationRequest

data class PipelineResult(val items: List<TranslationItem>, val metrics: Metrics)

/**
 * نص خام (من OCR) -> تصفية التكرار والتغيّر -> Cache -> دفعة واحدة إلى المزوّد -> نتائج.
 * لا يُرسَل للذكاء الاصطناعي إلا النص الجديد غير الموجود في الـ Cache، ولا تُرسل صور إطلاقاً.
 */
class TranslationPipeline(
    val cache: TranslationCache = TranslationCache(),
    val detector: TextChangeDetector = TextChangeDetector(),
    val memory: SessionMemory = SessionMemory(),
    private val now: () -> Long = { System.currentTimeMillis() }
) {
    private fun msSince(startNs: Long) = (System.nanoTime() - startNs) / 1_000_000

    suspend fun process(
        lines: List<String>,
        settings: AppSettings,
        provider: TranslationProvider,
        ocrMs: Long = 0
    ): PipelineResult {
        val start = System.nanoTime()
        val fresh = detector.filterNew(lines)
        if (fresh.isEmpty()) return PipelineResult(emptyList(), Metrics(ocrMs = ocrMs))

        val pair = "${settings.sourceLang}>${settings.targetLang}"
        val results = arrayOfNulls<String>(fresh.size)
        val misses = mutableListOf<Int>()
        fresh.forEachIndexed { i, line ->
            val cached = if (provider.cacheable) cache.get(pair, line) else null
            if (cached != null) results[i] = cached else misses.add(i)
        }

        var translateMs = 0L
        if (misses.isNotEmpty()) {
            val t0 = System.nanoTime()
            val translated = try {
                provider.translate(
                    TranslationRequest(
                        lines = misses.map { fresh[it] },
                        sourceLang = settings.sourceLang,
                        targetLang = settings.targetLang,
                        context = memory.snapshot(),
                        glossary = TextUtils.parseGlossary(settings.glossary)
                    )
                )
            } catch (e: Throwable) {
                detector.forget(fresh)
                throw e
            }
            translateMs = msSince(t0)
            misses.forEachIndexed { j, idx ->
                results[idx] = translated[j]
                if (provider.cacheable) cache.put(pair, fresh[idx], translated[j])
            }
        }

        val ts = now()
        val items = fresh.mapIndexed { i, line ->
            TranslationItem(line, results[i] ?: line, fromCache = i !in misses, timestamp = ts, pair = pair)
        }
        items.forEach { memory.add(it.source, it.translated) }
        return PipelineResult(
            items,
            Metrics(
                ocrMs = ocrMs, translateMs = translateMs, totalMs = ocrMs + msSince(start),
                lines = items.size, cacheHits = items.count { it.fromCache }
            )
        )
    }
}

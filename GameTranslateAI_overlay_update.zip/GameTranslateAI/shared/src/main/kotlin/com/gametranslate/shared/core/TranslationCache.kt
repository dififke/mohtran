package com.gametranslate.shared.core

/** ذاكرة مؤقتة LRU للترجمات، المفتاح = (زوج اللغات + النص بعد التطبيع). */
class TranslationCache(private val maxEntries: Int = 2000) {
    private val map = object : LinkedHashMap<String, String>(256, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, String>?) = size > maxEntries
    }

    private fun k(pair: String, text: String) = "$pair|${TextUtils.key(text)}"

    @Synchronized fun get(pair: String, text: String): String? = map[k(pair, text)]
    @Synchronized fun put(pair: String, text: String, translation: String) { map[k(pair, text)] = translation }
    @Synchronized fun clear() = map.clear()
    @Synchronized fun size(): Int = map.size
}

/** ذاكرة سياق الجلسة الحالية: آخر الأسطر المترجمة تُرسل مع كل طلب لتوحيد الأسلوب والمصطلحات. */
class SessionMemory(private val max: Int = 12) {
    private val items = ArrayDeque<Pair<String, String>>()

    @Synchronized fun add(source: String, translated: String) {
        items.addLast(source to translated)
        while (items.size > max) items.removeFirst()
    }
    @Synchronized fun snapshot(): List<Pair<String, String>> = items.toList()
    @Synchronized fun clear() = items.clear()
}

#!/usr/bin/env bash
# يبني التطبيقين ويضع ملفات APK في المجلد dist/
# المتطلبات: JDK 17+ و Android SDK (متغير ANDROID_HOME) و Gradle 8.7 (أو gradlew إن وُجد).
set -euo pipefail
cd "$(dirname "$0")/.."

if [ -x ./gradlew ]; then G=./gradlew
elif command -v gradle >/dev/null 2>&1; then G=gradle
else echo "لم يتم العثور على Gradle. ثبّته أو استخدم Android Studio أو GitHub Actions (راجع documentation/INSTALL_AR.md)"; exit 1; fi

SDK="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-}}"
if [ -z "$SDK" ]; then echo "ضع مسار Android SDK في المتغير ANDROID_HOME"; exit 1; fi
echo "sdk.dir=$SDK" > local.properties

$G --no-daemon :shared:testDebugUnitTest :android-tv:assembleDebug :android-mobile:assembleDebug

mkdir -p dist
cp android-tv/build/outputs/apk/debug/*.apk dist/GameTranslateAI-TV.apk
cp android-mobile/build/outputs/apk/debug/*.apk dist/GameTranslateAI-Phone.apk
echo "تم. الملفات في: $(pwd)/dist"

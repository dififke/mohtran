package com.gametranslate.shared.ui

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.gametranslate.shared.model.AppSettings
import com.gametranslate.shared.model.Metrics
import com.gametranslate.shared.model.TranslationItem
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** زر يعمل باللمس وبالريموت (D-pad) مع إطار تركيز واضح وتكبير خفيف عند التركيز. */
@Composable
fun GameButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    primary: Boolean = true,
    selected: Boolean = false,
    enabled: Boolean = true,
    focusRequester: FocusRequester? = null
) {
    var focused by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(if (focused) 1.05f else 1f, label = "buttonScale")
    val shape = RoundedCornerShape(14.dp)
    val colors = when {
        !enabled -> listOf(GameColors.Surface2, GameColors.Surface2)
        selected -> listOf(GameColors.Purple, GameColors.Blue)
        primary -> listOf(Color(0xFF7C3AED), Color(0xFF5B3FD6))
        else -> listOf(GameColors.Surface2, GameColors.Surface2)
    }
    Box(
        modifier = modifier
            .then(if (focusRequester != null) Modifier.focusRequester(focusRequester) else Modifier)
            .scale(scale)
            .clip(shape)
            .background(Brush.horizontalGradient(colors))
            .border(if (focused) 3.dp else 1.dp, if (focused) Color.White else GameColors.Border, shape)
            .onFocusChanged { focused = it.isFocused }
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 14.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text, color = if (enabled) Color.White else GameColors.Muted,
            fontWeight = FontWeight.Bold, fontSize = 16.sp, textAlign = TextAlign.Center
        )
    }
}

@Composable
fun GameCard(modifier: Modifier = Modifier, title: String? = null, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(18.dp)
    Column(
        modifier.clip(shape).background(GameColors.Surface).border(1.dp, GameColors.Border, shape).padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        if (title != null) Text(title, color = GameColors.PurpleLight, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        content()
    }
}

@Composable
fun StatusChip(text: String, color: Color, modifier: Modifier = Modifier) {
    Row(
        modifier.clip(RoundedCornerShape(50)).background(color.copy(alpha = 0.18f))
            .border(1.dp, color, RoundedCornerShape(50)).padding(horizontal = 14.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Box(Modifier.size(10.dp).clip(RoundedCornerShape(50)).background(color))
        Text(text, color = color, fontWeight = FontWeight.Bold, fontSize = 14.sp)
    }
}

/** معاينة الترجمة بإعدادات المستخدم (الخط واللون والخلفية والشفافية). */
@Composable
fun SubtitleBox(settings: AppSettings, text: String, modifier: Modifier = Modifier) {
    Box(
        modifier.clip(RoundedCornerShape(12.dp))
            .background(Color(settings.backgroundColor).copy(alpha = settings.backgroundOpacity))
            .padding(horizontal = 24.dp, vertical = 14.dp)
    ) {
        Text(
            text, color = Color(settings.textColor), fontSize = settings.fontSizeSp.sp,
            lineHeight = (settings.fontSizeSp * 1.4f).sp, fontWeight = FontWeight.SemiBold,
            textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth()
        )
    }
}

@Composable
fun MetricsCard(m: Metrics, modifier: Modifier = Modifier) {
    GameCard(modifier, S.metricsTitle) {
        Text("OCR: ${m.ocrMs} ms   |   الترجمة: ${m.translateMs} ms   |   الإجمالي: ${m.totalMs} ms", color = GameColors.Text, fontSize = 15.sp)
        Text("الأسطر: ${m.lines}   |   من الذاكرة المؤقتة: ${m.cacheHits}", color = GameColors.Muted, fontSize = 14.sp)
        Text(S.metricsNote, color = GameColors.Muted, fontSize = 12.sp)
    }
}

@Composable
fun HistoryList(list: List<TranslationItem>, modifier: Modifier = Modifier) {
    if (list.isEmpty()) {
        Box(modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) {
            Text(S.noHistory, color = GameColors.Muted, fontSize = 16.sp)
        }
        return
    }
    val fmt = remember { SimpleDateFormat("HH:mm:ss", Locale.US) }
    LazyColumn(modifier, verticalArrangement = Arrangement.spacedBy(10.dp)) {
        items(list) { item ->
            var focused by remember { mutableStateOf(false) }
            val shape = RoundedCornerShape(14.dp)
            Column(
                Modifier.fillMaxWidth().clip(shape).background(GameColors.Surface)
                    .border(if (focused) 3.dp else 1.dp, if (focused) GameColors.Blue else GameColors.Border, shape)
                    .onFocusChanged { focused = it.isFocused }.focusable()
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    item.source, color = GameColors.Muted, fontSize = 13.sp,
                    style = TextStyle(textDirection = TextDirection.Ltr), modifier = Modifier.fillMaxWidth()
                )
                Text(item.translated, color = GameColors.Text, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text(
                    fmt.format(Date(item.timestamp)) + if (item.fromCache) "  •  من الذاكرة المؤقتة" else "",
                    color = GameColors.PurpleLight, fontSize = 11.sp
                )
            }
        }
    }
}

package com.gametranslate.shared.translate

import kotlinx.serialization.json.Json
import kotlinx.serialization.json.addJsonObject
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import kotlinx.serialization.json.putJsonArray
import kotlinx.serialization.json.putJsonObject
import okhttp3.OkHttpClient

/** Google Gemini عبر REST. المفتاح يُرسل في ترويسة x-goog-api-key وليس في الرابط. */
class GeminiProvider(
    private val apiKey: () -> String,
    private val model: () -> String,
    private val client: OkHttpClient = OkHttpClient(),
    private val baseUrl: String = "https://generativelanguage.googleapis.com/v1beta"
) : TranslationProvider {
    override val name = "Gemini"

    override suspend fun translate(request: TranslationRequest): List<String> {
        val key = apiKey().trim()
        if (key.isEmpty()) throw TranslationException.MissingKey()
        val body = buildJsonObject {
            putJsonObject("systemInstruction") {
                putJsonArray("parts") { addJsonObject { put("text", PromptBuilder.system(request)) } }
            }
            putJsonArray("contents") {
                addJsonObject {
                    put("role", "user")
                    putJsonArray("parts") { addJsonObject { put("text", PromptBuilder.user(request)) } }
                }
            }
            putJsonObject("generationConfig") {
                put("temperature", 0.2)
                put("responseMimeType", "application/json")
            }
        }.toString()
        val (code, text) = client.postJson(
            "$baseUrl/models/${model().trim()}:generateContent",
            mapOf("x-goog-api-key" to key), body
        )
        checkStatus(code, text)
        val out = try {
            Json.parseToJsonElement(text).jsonObject["candidates"]!!.jsonArray[0].jsonObject["content"]!!
                .jsonObject["parts"]!!.jsonArray[0].jsonObject["text"]!!.jsonPrimitive.content
        } catch (e: Exception) {
            throw TranslationException.BadResponse()
        }
        return ResponseParser.parseArray(out, request.lines.size)
    }
}

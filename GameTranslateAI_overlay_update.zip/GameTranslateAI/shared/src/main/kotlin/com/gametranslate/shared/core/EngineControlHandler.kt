package com.gametranslate.shared.core

import com.gametranslate.shared.model.*
import com.gametranslate.shared.net.ControlHandler

/** يربط أوامر الشبكة (من الهاتف أو الكمبيوتر) بمحرك الترجمة على التلفاز. */
class EngineControlHandler(
    private val engine: TranslationEngine,
    private val repo: SettingsRepository,
    private val deviceName: () -> String
) : ControlHandler {
    override suspend fun status() = engine.status(deviceName())

    override suspend fun command(action: String): SimpleResult = when (action) {
        "start" -> { engine.start(); SimpleResult(true, "بدأت الترجمة") }
        "stop" -> { engine.stop(); SimpleResult(true, "توقفت الترجمة") }
        "pause" -> { engine.pause(); SimpleResult(true, "إيقاف مؤقت") }
        "resume" -> { engine.resume(); SimpleResult(true, "تم الاستئناف") }
        else -> SimpleResult(false, "أمر غير معروف: $action")
    }

    override suspend fun getSettings() = repo.settings.value
    override suspend fun updateSettings(s: AppSettings): SimpleResult { repo.update { s }; return SimpleResult(true, "تم الحفظ") }
    override suspend fun updateKeys(k: KeysUpdate): SimpleResult {
        repo.updateKeys(k.geminiKey, k.openAiKey)
        return SimpleResult(true, "تم حفظ المفتاح على التلفاز")
    }
    override suspend fun history(limit: Int) = engine.history.value.take(limit)
    override suspend fun clearHistory(): SimpleResult { engine.clearHistory(); return SimpleResult(true, "تم مسح السجل") }
    override suspend fun submitText(lines: List<String>) = engine.submitLines(lines)
    override suspend fun submitFrame(bytes: ByteArray) = engine.submitFrame(bytes)
    override suspend fun runTest() = engine.runDemo()
}

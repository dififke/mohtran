package com.gametranslate.shared.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection

object GameColors {
    val Bg = Color(0xFF0A0A0F)
    val Bg2 = Color(0xFF14141F)
    val Surface = Color(0xFF16161F)
    val Surface2 = Color(0xFF22222F)
    val Border = Color(0xFF34344A)
    val Purple = Color(0xFF8B5CF6)
    val PurpleLight = Color(0xFFB69CFF)
    val Blue = Color(0xFF3B82F6)
    val Text = Color(0xFFEDEDF5)
    val Muted = Color(0xFF9A9AB5)
    val Success = Color(0xFF22C55E)
    val Warning = Color(0xFFF59E0B)
    val Error = Color(0xFFEF4444)
}

/** ثيم الألعاب الداكن + اتجاه RTL إجباري لكل الواجهة. */
@Composable
fun GameTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = GameColors.Purple, secondary = GameColors.Blue,
            background = GameColors.Bg, surface = GameColors.Surface,
            onPrimary = Color.White, onBackground = GameColors.Text, onSurface = GameColors.Text,
            error = GameColors.Error
        )
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Box(
                Modifier.fillMaxSize()
                    .background(Brush.verticalGradient(listOf(GameColors.Bg, GameColors.Bg2)))
            ) { content() }
        }
    }
}

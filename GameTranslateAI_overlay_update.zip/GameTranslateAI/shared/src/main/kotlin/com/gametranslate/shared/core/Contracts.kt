package com.gametranslate.shared.core

import com.gametranslate.shared.model.AppSettings
import com.gametranslate.shared.model.RegionPreset
import com.gametranslate.shared.model.TranslationItem
import kotlinx.coroutines.flow.StateFlow

/** قراءة النص من صورة. التنفيذ الفعلي (ML Kit) في طبقة Android، ويمكن إضافة مصادر أخرى لاحقاً. */
fun interface FrameOcr {
    suspend fun recognize(image: ByteArray, region: RegionPreset): List<String>
}

interface HistoryStore {
    suspend fun add(items: List<TranslationItem>)
    suspend fun recent(limit: Int): List<TranslationItem>
    suspend fun clear()
}

class InMemoryHistoryStore : HistoryStore {
    private val list = mutableListOf<TranslationItem>()
    @Synchronized override suspend fun add(items: List<TranslationItem>) { list.addAll(items) }
    @Synchronized override suspend fun recent(limit: Int) = list.asReversed().take(limit)
    @Synchronized override suspend fun clear() = list.clear()
}

data class ApiKeys(val gemini: String = "", val openAi: String = "")

interface SettingsRepository {
    val settings: StateFlow<AppSettings>
    fun update(transform: (AppSettings) -> AppSettings)
    fun keys(): ApiKeys
    fun updateKeys(gemini: String?, openAi: String?)
}

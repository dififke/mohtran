package com.gametranslate.shared.data

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKeys
import com.gametranslate.shared.core.ApiKeys
import com.gametranslate.shared.core.SettingsRepository
import com.gametranslate.shared.model.AppSettings
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

/**
 * تخزين المفاتيح والأسرار مشفّراً عبر Android Keystore.
 * إن فشل التشفير على جهاز معيّن تُحفظ القيم في الذاكرة فقط (لا تُكتب نصاً صريحاً على القرص).
 */
class SecureStore(context: Context) {
    private val prefs: SharedPreferences? = try {
        val masterKey = MasterKeys.getOrCreate(MasterKeys.AES256_GCM_SPEC)
        EncryptedSharedPreferences.create(
            "secure_store", masterKey, context.applicationContext,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    } catch (e: Exception) {
        null
    }
    private val fallback = HashMap<String, String>()

    val isPersistent: Boolean get() = prefs != null

    fun get(name: String): String = prefs?.getString(name, "") ?: fallback[name].orEmpty()
    fun put(name: String, value: String) {
        if (prefs != null) prefs.edit().putString(name, value).apply() else fallback[name] = value
    }
}

class SettingsStore(context: Context, val secure: SecureStore = SecureStore(context)) : SettingsRepository {
    private val prefs = context.applicationContext.getSharedPreferences("settings", Context.MODE_PRIVATE)
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }

    private val _settings = MutableStateFlow(load())
    override val settings: StateFlow<AppSettings> = _settings.asStateFlow()

    private fun load(): AppSettings = try {
        prefs.getString("json", null)?.let { json.decodeFromString<AppSettings>(it) } ?: AppSettings()
    } catch (e: Exception) {
        AppSettings()
    }

    @Synchronized
    override fun update(transform: (AppSettings) -> AppSettings) {
        val n = transform(_settings.value)
        _settings.value = n
        prefs.edit().putString("json", json.encodeToString(n)).apply()
    }

    override fun keys() = ApiKeys(secure.get("gemini_key"), secure.get("openai_key"))

    override fun updateKeys(gemini: String?, openAi: String?) {
        gemini?.let { secure.put("gemini_key", it.trim()) }
        openAi?.let { secure.put("openai_key", it.trim()) }
    }
}

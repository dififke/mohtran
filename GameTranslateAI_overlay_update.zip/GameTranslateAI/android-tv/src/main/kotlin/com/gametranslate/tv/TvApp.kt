package com.gametranslate.tv

import android.app.Application
import android.os.Build
import com.gametranslate.shared.core.EngineControlHandler
import com.gametranslate.shared.core.TranslationEngine
import com.gametranslate.shared.data.AppDatabase
import com.gametranslate.shared.data.RoomHistoryStore
import com.gametranslate.shared.data.SettingsStore
import com.gametranslate.shared.model.DEFAULT_PORT
import com.gametranslate.shared.net.LocalControlServer
import com.gametranslate.shared.net.Nsd
import com.gametranslate.shared.ocr.DemoFrames
import com.gametranslate.shared.ocr.MlKitFrameOcr
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.security.SecureRandom

class TvApp : Application() {
    lateinit var container: TvContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = TvContainer(this)
    }
}

/** يجمع مكونات التطبيق: الإعدادات، OCR، المحرك، خادم التحكم، والإعلان عن الجهاز على الشبكة. */
class TvContainer(private val app: Application) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    val settings = SettingsStore(app)
    private val db = AppDatabase.create(app)
    val deviceName = "GameTranslate TV (${Build.MODEL})"

    val engine = TranslationEngine(
        scope = scope,
        repo = settings,
        ocr = MlKitFrameOcr(),
        historyStore = RoomHistoryStore(db.historyDao()),
        demoFrame = DemoFrames::render
    )

    private val handler = EngineControlHandler(engine, settings) { deviceName }

    private val _pin = MutableStateFlow(loadPin())
    val pin: StateFlow<String> = _pin

    private val _serverError = MutableStateFlow<String?>(null)
    val serverError: StateFlow<String?> = _serverError

    private var server: LocalControlServer? = null
    private var nsd: Nsd.Registration? = null

    private fun newPin() = "%06d".format(SecureRandom().nextInt(1_000_000))

    private fun loadPin(): String {
        var p = settings.secure.get("pin")
        if (p.length != 6) {
            p = newPin()
            settings.secure.put("pin", p)
        }
        return p
    }

    fun regeneratePin() {
        val p = newPin()
        settings.secure.put("pin", p)
        _pin.value = p
    }

    @Synchronized
    fun startServer() {
        if (server != null) return
        try {
            val s = LocalControlServer(DEFAULT_PORT, { _pin.value }, { deviceName }, handler, scope)
            s.start()
            server = s
            _serverError.value = null
            nsd = Nsd.Registration(app, deviceName, DEFAULT_PORT).also { it.register() }
        } catch (e: Exception) {
            _serverError.value = "تعذر تشغيل خادم التحكم على المنفذ $DEFAULT_PORT (${e.message})"
        }
    }

    @Synchronized
    fun stopServer() {
        nsd?.unregister()
        nsd = null
        server?.stop()
        server = null
    }
}

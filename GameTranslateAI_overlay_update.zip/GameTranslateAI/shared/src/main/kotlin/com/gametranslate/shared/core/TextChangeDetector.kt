package com.gametranslate.shared.core

/**
 * يكتشف تغيّر النص: يتجاهل النصوص التي ظهرت مؤخراً (تطابق تام أو تشابه عالٍ
 * ناتج عن اهتزاز OCR)، فلا يُعاد إرسالها للترجمة.
 */
class TextChangeDetector(
    private val windowSize: Int = 64,
    private val threshold: Double = 0.88
) {
    private val recent = ArrayDeque<String>()

    @Synchronized
    fun filterNew(lines: List<String>): List<String> {
        val out = mutableListOf<String>()
        for (raw in lines) {
            val n = TextUtils.normalize(raw)
            if (!TextUtils.isTranslatable(n)) continue
            val k = TextUtils.key(n)
            if (recent.any { it == k || TextUtils.similarity(it, k) >= threshold }) continue
            if (out.any { TextUtils.key(it) == k }) continue
            out.add(n)
            recent.addLast(k)
            if (recent.size > windowSize) recent.removeFirst()
        }
        return out
    }

    /** يُستدعى عند فشل الترجمة كي تُعاد المحاولة لاحقاً. */
    @Synchronized
    fun forget(lines: List<String>) {
        val keys = lines.map { TextUtils.key(it) }.toSet()
        recent.removeAll(keys)
    }

    @Synchronized
    fun reset() = recent.clear()
}

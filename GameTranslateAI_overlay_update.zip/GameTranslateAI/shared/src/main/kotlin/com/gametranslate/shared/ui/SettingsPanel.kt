package com.gametranslate.shared.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.gametranslate.shared.model.*

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun <T> ChoiceRow(label: String, options: List<Pair<String, T>>, selected: T, onSelect: (T) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(label, color = GameColors.Muted, fontSize = 14.sp)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            options.forEach { (title, value) ->
                GameButton(title, { onSelect(value) }, primary = false, selected = value == selected)
            }
        }
    }
}

private val langSources = listOf("English" to "en", "Français" to "fr", "Español" to "es", "Deutsch" to "de", "Italiano" to "it", "Português" to "pt")
private val langTargets = listOf("العربية" to "ar", "English" to "en")
private val textColors = listOf("أبيض" to 0xFFFFFFFFL, "أصفر" to 0xFFFFEB3BL, "سماوي" to 0xFF22D3EEL, "أخضر" to 0xFF4ADE80L)
private val bgColors = listOf("أسود" to 0xFF000000L, "رمادي داكن" to 0xFF1F1F2BL, "بنفسجي داكن" to 0xFF2A1B5EL)

/** لوحة إعدادات مشتركة. على التلفاز تعمل بالريموت، وعلى الهاتف تُرسل التعديلات إلى التلفاز. */
@Composable
fun SettingsPanel(settings: AppSettings, onChange: (AppSettings) -> Unit, advanced: Boolean, modifier: Modifier = Modifier) {
    Column(modifier, verticalArrangement = Arrangement.spacedBy(18.dp)) {
        ChoiceRow(
            S.provider,
            listOf("تجريبي (بدون مفتاح)" to ProviderType.DEMO, "Google Gemini" to ProviderType.GEMINI, "OpenAI-compatible" to ProviderType.OPENAI),
            settings.provider
        ) { onChange(settings.copy(provider = it)) }
        ChoiceRow(S.sourceLang, langSources, settings.sourceLang) { onChange(settings.copy(sourceLang = it)) }
        ChoiceRow(S.targetLang, langTargets, settings.targetLang) { onChange(settings.copy(targetLang = it)) }
        ChoiceRow(S.fontSize, listOf(22, 26, 30, 36, 44, 52).map { "$it" to it }, settings.fontSizeSp) { onChange(settings.copy(fontSizeSp = it)) }
        ChoiceRow(S.textColor, textColors, settings.textColor) { onChange(settings.copy(textColor = it)) }
        ChoiceRow(S.bgColor, bgColors, settings.backgroundColor) { onChange(settings.copy(backgroundColor = it)) }
        ChoiceRow(S.opacity, listOf("0%" to 0f, "30%" to 0.3f, "60%" to 0.6f, "85%" to 0.85f, "100%" to 1f), settings.backgroundOpacity) { onChange(settings.copy(backgroundOpacity = it)) }
        ChoiceRow(S.position, listOf("أعلى" to SubtitlePosition.TOP, "وسط" to SubtitlePosition.CENTER, "أسفل" to SubtitlePosition.BOTTOM), settings.position) { onChange(settings.copy(position = it)) }
        ChoiceRow(S.interval, listOf(300L, 500L, 700L, 1000L, 1500L).map { "$it" to it }, settings.captureIntervalMs) { onChange(settings.copy(captureIntervalMs = it)) }
        ChoiceRow(
            S.region,
            listOf("الشاشة كاملة" to RegionPreset.FULL, "الثلث السفلي (حوارات)" to RegionPreset.BOTTOM_THIRD, "النصف السفلي" to RegionPreset.BOTTOM_HALF, "النصف العلوي" to RegionPreset.TOP_HALF),
            settings.region
        ) { onChange(settings.copy(region = it)) }

        if (advanced) AdvancedFields(settings, onChange)
    }
}

@Composable
private fun AdvancedFields(settings: AppSettings, onChange: (AppSettings) -> Unit) {
    var gm by remember(settings.geminiModel) { mutableStateOf(settings.geminiModel) }
    var ob by remember(settings.openAiBaseUrl) { mutableStateOf(settings.openAiBaseUrl) }
    var om by remember(settings.openAiModel) { mutableStateOf(settings.openAiModel) }
    var gl by remember(settings.glossary) { mutableStateOf(settings.glossary) }
    val ltr = TextStyle(textDirection = TextDirection.Ltr)
    GameCard(title = "إعدادات متقدمة للمحرك") {
        OutlinedTextField(gm, { gm = it }, label = { Text("Gemini model") }, textStyle = ltr, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(ob, { ob = it }, label = { Text("OpenAI base URL") }, textStyle = ltr, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(om, { om = it }, label = { Text("OpenAI model") }, textStyle = ltr, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(gl, { gl = it }, label = { Text(S.glossary) }, minLines = 3, modifier = Modifier.fillMaxWidth())
        GameButton(S.saveEngine, {
            onChange(settings.copy(geminiModel = gm.trim(), openAiBaseUrl = ob.trim(), openAiModel = om.trim(), glossary = gl))
        }, modifier = Modifier.fillMaxWidth())
    }
}

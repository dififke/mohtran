package com.gametranslate.shared

import com.gametranslate.shared.translate.*
import kotlinx.coroutines.runBlocking
import okhttp3.mockwebserver.MockResponse
import okhttp3.mockwebserver.MockWebServer
import org.junit.Assert.*
import org.junit.Test

class ProviderHttpTest {
    private val req = TranslationRequest(listOf("Hello"), "en", "ar")

    @Test fun geminiSuccess() = runBlocking {
        val server = MockWebServer()
        server.enqueue(MockResponse().setBody("""{"candidates":[{"content":{"parts":[{"text":"[\"مرحباً\"]"}]}}]}"""))
        server.start()
        val p = GeminiProvider({ "KEY" }, { "gemini-test" }, baseUrl = server.url("/v1beta").toString().trimEnd('/'))
        assertEquals(listOf("مرحباً"), p.translate(req))
        val recorded = server.takeRequest()
        assertEquals("KEY", recorded.getHeader("x-goog-api-key"))
        assertTrue(recorded.path!!.contains("gemini-test:generateContent"))
        server.shutdown()
    }

    @Test fun geminiInvalidKey() = runBlocking {
        val server = MockWebServer()
        server.enqueue(MockResponse().setResponseCode(400).setBody("""{"error":{"message":"API key not valid. Please pass a valid API key.","status":"INVALID_ARGUMENT"}}"""))
        server.start()
        val p = GeminiProvider({ "BAD" }, { "m" }, baseUrl = server.url("/v1beta").toString().trimEnd('/'))
        try { p.translate(req); fail() } catch (e: TranslationException.InvalidKey) { }
        server.shutdown()
    }

    @Test fun missingKey() = runBlocking {
        try { GeminiProvider({ "" }, { "m" }).translate(req); fail() } catch (e: TranslationException.MissingKey) { }
    }

    @Test fun openAiSuccessAndUnauthorized() = runBlocking {
        val server = MockWebServer()
        server.enqueue(MockResponse().setBody("""{"choices":[{"message":{"content":"[\"مرحباً\"]"}}]}"""))
        server.enqueue(MockResponse().setResponseCode(401).setBody("""{"error":"nope"}"""))
        server.start()
        val base = server.url("/v1").toString()
        val p = OpenAiProvider({ "K" }, { base }, { "m" })
        assertEquals(listOf("مرحباً"), p.translate(req))
        assertEquals("Bearer K", server.takeRequest().getHeader("Authorization"))
        try { p.translate(req); fail() } catch (e: TranslationException.InvalidKey) { }
        server.shutdown()
    }

    @Test fun rateLimited() = runBlocking {
        val server = MockWebServer()
        server.enqueue(MockResponse().setResponseCode(429))
        server.start()
        val p = OpenAiProvider({ "K" }, { server.url("/v1").toString() }, { "m" })
        try { p.translate(req); fail() } catch (e: TranslationException.RateLimited) { }
        server.shutdown()
    }

    @Test fun networkFailure() = runBlocking {
        val server = MockWebServer()
        server.start()
        val url = server.url("/v1").toString()
        server.shutdown() // لا أحد يستمع الآن
        val p = OpenAiProvider({ "K" }, { url }, { "m" })
        try { p.translate(req); fail() } catch (e: TranslationException.Network) { }
    }
}

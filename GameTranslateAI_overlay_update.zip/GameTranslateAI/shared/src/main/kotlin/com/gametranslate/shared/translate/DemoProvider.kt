package com.gametranslate.shared.translate

import com.gametranslate.shared.core.TextUtils

/**
 * الوضع التجريبي: قاموس صغير مدمج للنصوص التجريبية فقط (ليس ترجمة حقيقية).
 * أي نص آخر يظهر بعلامة [تجريبي] ليتضح أنه غير مترجم فعلياً.
 */
object DemoProvider : TranslationProvider {
    override val name = "Demo"
    override val cacheable = false

    private val dict = mapOf(
        "new game" to "لعبة جديدة",
        "continue" to "متابعة",
        "settings" to "الإعدادات",
        "inventory" to "الحقيبة",
        "press x to continue" to "اضغط X للمتابعة",
        "quest: find the lost sword" to "المهمة: ابحث عن السيف المفقود",
        "kratos: we must leave before dawn." to "كريتوس: يجب أن نغادر قبل الفجر.",
        "objective updated" to "تم تحديث الهدف"
    )

    override suspend fun translate(request: TranslationRequest): List<String> =
        request.lines.map { dict[TextUtils.key(it)] ?: "[تجريبي] $it" }
}

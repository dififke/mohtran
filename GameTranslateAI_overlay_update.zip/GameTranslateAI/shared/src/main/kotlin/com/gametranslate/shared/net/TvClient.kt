package com.gametranslate.shared.net

import com.gametranslate.shared.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.builtins.ListSerializer
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException
import java.util.concurrent.TimeUnit

class TvClientException(val kind: Kind, message: String) : Exception(message) {
    enum class Kind { UNREACHABLE, UNAUTHORIZED, SERVER }
}

/** عميل يستخدمه تطبيق الهاتف (ويمكن استخدامه من أي أداة) للتحكم بتطبيق التلفاز. */
class TvClient(
    var host: String,
    var token: String,
    var port: Int = DEFAULT_PORT,
    private val http: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(4, TimeUnit.SECONDS)
        .readTimeout(40, TimeUnit.SECONDS)
        .build()
) {
    private val jsonType = "application/json; charset=utf-8".toMediaType()

    private suspend fun exec(method: String, path: String, body: RequestBody? = null): String =
        withContext(Dispatchers.IO) {
            try {
                val req = Request.Builder().url("http://$host:$port$path")
                    .header("X-Token", token)
                    .method(method, body ?: if (method == "POST") ByteArray(0).toRequestBody() else null)
                    .build()
                http.newCall(req).execute().use { r ->
                    val txt = r.body?.string().orEmpty()
                    when {
                        r.code == 401 -> throw TvClientException(TvClientException.Kind.UNAUTHORIZED, "رمز الاقتران (PIN) غير صحيح")
                        !r.isSuccessful -> throw TvClientException(TvClientException.Kind.SERVER, "خطأ من التلفاز (HTTP ${r.code})")
                        else -> txt
                    }
                }
            } catch (e: IOException) {
                throw TvClientException(TvClientException.Kind.UNREACHABLE, "تعذر الوصول إلى التلفاز. تأكد من العنوان ومن أن التطبيق مفتوح على التلفاز")
            } catch (e: IllegalArgumentException) {
                throw TvClientException(TvClientException.Kind.UNREACHABLE, "عنوان التلفاز غير صالح")
            }
        }

    private fun json(s: String) = s.toRequestBody(jsonType)

    suspend fun ping(): PingResponse = ControlJson.decodeFromString(exec("GET", "/api/ping"))
    suspend fun status(): EngineStatus = ControlJson.decodeFromString(exec("GET", "/api/status"))
    suspend fun command(action: String): SimpleResult =
        ControlJson.decodeFromString(exec("POST", "/api/command", json(ControlJson.encodeToString(CommandRequest(action)))))
    suspend fun getSettings(): AppSettings = ControlJson.decodeFromString(exec("GET", "/api/settings"))
    suspend fun updateSettings(s: AppSettings): SimpleResult =
        ControlJson.decodeFromString(exec("POST", "/api/settings", json(ControlJson.encodeToString(s))))
    suspend fun updateKeys(k: KeysUpdate): SimpleResult =
        ControlJson.decodeFromString(exec("POST", "/api/keys", json(ControlJson.encodeToString(k))))
    suspend fun history(limit: Int = 50): List<TranslationItem> =
        ControlJson.decodeFromString(ListSerializer(TranslationItem.serializer()), exec("GET", "/api/history?limit=$limit"))
    suspend fun clearHistory(): SimpleResult = ControlJson.decodeFromString(exec("DELETE", "/api/history"))
    suspend fun sendText(lines: List<String>): SimpleResult =
        ControlJson.decodeFromString(exec("POST", "/api/text", json(ControlJson.encodeToString(TextSubmission(lines)))))
    suspend fun sendFrame(bytes: ByteArray): SimpleResult =
        ControlJson.decodeFromString(exec("POST", "/api/frame", bytes.toRequestBody("application/octet-stream".toMediaType())))
    suspend fun runTest(): SimpleResult = ControlJson.decodeFromString(exec("POST", "/api/test"))
}

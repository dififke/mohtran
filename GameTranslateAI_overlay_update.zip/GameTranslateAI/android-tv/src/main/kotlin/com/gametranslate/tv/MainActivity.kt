package com.gametranslate.tv

import android.os.Bundle
import android.content.Intent
import android.provider.Settings
import android.net.Uri
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.gametranslate.shared.ui.GameTheme

class MainActivity : ComponentActivity() {
    private val container get() = (application as TvApp).container

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        container.startServer()
        setContent { GameTheme { TvRoot(container) } }
    }

    override fun onResume() {
        super.onResume()
        if (Settings.canDrawOverlays(this)) {
            runCatching { startService(Intent(this, OverlaySubtitleService::class.java)) }
        }
    }

    override fun onDestroy() {
        if (isFinishing) container.stopServer()
        super.onDestroy()
    }
}

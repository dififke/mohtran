package com.gametranslate.shared

import com.gametranslate.shared.core.*
import com.gametranslate.shared.model.*
import com.gametranslate.shared.net.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test

/** اختبار حقيقي للاتصال بين "الهاتف" (TvClient) و"التلفاز" (LocalControlServer + المحرك) عبر مقبس محلي. */
class PhoneTvLinkTest {
    private class FakeRepo : SettingsRepository {
        private val s = MutableStateFlow(AppSettings())
        override val settings: StateFlow<AppSettings> = s
        override fun update(transform: (AppSettings) -> AppSettings) { s.value = transform(s.value) }
        private var k = ApiKeys()
        override fun keys() = k
        override fun updateKeys(gemini: String?, openAi: String?) { k = ApiKeys(gemini ?: k.gemini, openAi ?: k.openAi) }
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private lateinit var server: LocalControlServer
    private lateinit var repo: FakeRepo
    private lateinit var client: TvClient

    @Before fun setUp() {
        repo = FakeRepo()
        val ocr = FrameOcr { _, _ -> listOf("Press X to continue") } // OCR وهمي للاختبار فقط
        val engine = TranslationEngine(scope, repo, ocr, InMemoryHistoryStore())
        server = LocalControlServer(0, { "123456" }, { "TestTV" }, EngineControlHandler(engine, repo) { "TestTV" }, scope)
        server.start()
        client = TvClient("127.0.0.1", "123456", server.boundPort)
    }

    @After fun tearDown() { server.stop(); scope.cancel() }

    @Test fun pingNeedsNoToken() = runBlocking {
        assertEquals("TestTV", TvClient("127.0.0.1", "wrong", server.boundPort).ping().name)
    }

    @Test fun wrongPinIsRejected() = runBlocking {
        try { TvClient("127.0.0.1", "000000", server.boundPort).status(); fail() }
        catch (e: TvClientException) { assertEquals(TvClientException.Kind.UNAUTHORIZED, e.kind) }
    }

    @Test fun unreachableTv() = runBlocking {
        server.stop()
        try { client.status(); fail() } catch (e: TvClientException) { assertEquals(TvClientException.Kind.UNREACHABLE, e.kind) }
    }

    @Test fun commandsSettingsAndTextFlow() = runBlocking {
        assertFalse(client.status().running)
        // قبل البدء: النص يُرفض
        assertFalse(client.sendText(listOf("Continue")).ok)
        assertTrue(client.command("start").ok)
        assertTrue(client.status().running)

        val r = client.sendText(listOf("Continue", "Settings"))
        assertTrue(r.ok)
        assertEquals("متابعة\nالإعدادات", r.subtitle)
        assertEquals(2, client.history().size)

        assertTrue(client.command("pause").ok)
        assertTrue(client.status().paused)
        assertFalse(client.sendText(listOf("New Game")).ok)
        client.command("resume")

        client.updateSettings(client.getSettings().copy(fontSizeSp = 44, position = SubtitlePosition.TOP))
        assertEquals(44, repo.settings.value.fontSizeSp)
        assertEquals(SubtitlePosition.TOP, client.getSettings().position)

        client.updateKeys(KeysUpdate(geminiKey = "abc"))
        assertEquals("abc", repo.keys().gemini)
        assertFalse(client.command("explode").ok)
        assertTrue(client.command("stop").ok)
    }

    @Test fun frameGoesThroughOcrThenTranslate() = runBlocking {
        client.command("start")
        val r = client.sendFrame(ByteArray(10) { 1 })
        assertTrue(r.ok)
        assertEquals("اضغط X للمتابعة", r.subtitle)
        assertNotNull(r.metrics)
    }

    @Test fun missingKeyFallsBackToDemo() = runBlocking {
        client.updateSettings(client.getSettings().copy(provider = ProviderType.GEMINI))
        client.command("start")
        val r = client.sendText(listOf("Continue"))
        assertTrue(r.ok)
        assertTrue(client.status().notice!!.contains("الوضع التجريبي"))
    }
}

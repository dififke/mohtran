package com.gametranslate.shared.net

import com.gametranslate.shared.model.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.BufferedInputStream
import java.io.DataInputStream
import java.io.InputStream
import java.io.OutputStream
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.security.MessageDigest

interface ControlHandler {
    suspend fun status(): EngineStatus
    suspend fun command(action: String): SimpleResult
    suspend fun getSettings(): AppSettings
    suspend fun updateSettings(s: AppSettings): SimpleResult
    suspend fun updateKeys(k: KeysUpdate): SimpleResult
    suspend fun history(limit: Int): List<TranslationItem>
    suspend fun clearHistory(): SimpleResult
    suspend fun submitText(lines: List<String>): SimpleResult
    suspend fun submitFrame(bytes: ByteArray): SimpleResult
    suspend fun runTest(): SimpleResult
}

val ControlJson = Json { ignoreUnknownKeys = true; encodeDefaults = true }

/**
 * خادم HTTP بسيط على الشبكة المحلية يعمل على التلفاز (بدون مكتبات خارجية).
 * كل المسارات ما عدا /api/ping تتطلب ترويسة X-Token تطابق رمز الاقتران (PIN) المعروض على التلفاز.
 * تنبيه: الاتصال HTTP غير مشفّر، فاستخدمه على شبكة منزلية موثوقة فقط.
 */
class LocalControlServer(
    private val port: Int,
    private val token: () -> String,
    private val deviceName: () -> String,
    private val handler: ControlHandler,
    private val scope: CoroutineScope
) {
    private var server: ServerSocket? = null
    private var job: Job? = null
    val boundPort: Int get() = server?.localPort ?: -1

    fun start() {
        if (server != null) return
        val s = ServerSocket()
        s.reuseAddress = true
        s.bind(InetSocketAddress(port))
        server = s
        job = scope.launch(Dispatchers.IO) {
            while (!s.isClosed) {
                val sock = try { s.accept() } catch (e: Exception) { break }
                launch(Dispatchers.IO) { runCatching { handle(sock) } }
            }
        }
    }

    fun stop() {
        runCatching { server?.close() }
        server = null
        job?.cancel()
        job = null
    }

    private fun readLine(input: InputStream): String? {
        val sb = StringBuilder()
        while (true) {
            val b = input.read()
            if (b == -1) return if (sb.isEmpty()) null else sb.toString()
            if (b == '\n'.code) return sb.toString().trimEnd('\r')
            sb.append(b.toChar())
            if (sb.length > 8192) return null
        }
    }

    private suspend fun handle(sock: Socket) {
        sock.use { s ->
            s.soTimeout = 15_000
            val input = BufferedInputStream(s.getInputStream())
            val out = s.getOutputStream()
            val requestLine = readLine(input) ?: return
            val parts = requestLine.split(" ")
            if (parts.size < 2) return
            val method = parts[0]
            val target = parts[1]
            val headers = HashMap<String, String>()
            while (true) {
                val l = readLine(input) ?: break
                if (l.isEmpty()) break
                val i = l.indexOf(':')
                if (i > 0) headers[l.substring(0, i).trim().lowercase()] = l.substring(i + 1).trim()
            }
            val len = headers["content-length"]?.toIntOrNull() ?: 0
            if (len < 0 || len > MAX_BODY) { respond(out, 413, SimpleResult(false, "الطلب كبير جداً")); return }
            val body = ByteArray(len)
            if (len > 0) DataInputStream(input).readFully(body)

            val path = target.substringBefore('?')
            val query = target.substringAfter('?', "")
            try {
                route(out, method, path, query, headers, body)
            } catch (e: kotlinx.serialization.SerializationException) {
                respond(out, 400, SimpleResult(false, "طلب غير صالح"))
            } catch (e: IllegalArgumentException) {
                respond(out, 400, SimpleResult(false, "طلب غير صالح"))
            } catch (e: Exception) {
                respond(out, 500, SimpleResult(false, "خطأ داخلي"))
            }
        }
    }

    private fun tokenOk(given: String?): Boolean {
        val expected = token()
        if (given == null || expected.isEmpty()) return false
        return MessageDigest.isEqual(given.toByteArray(), expected.toByteArray())
    }

    private suspend fun route(out: OutputStream, method: String, path: String, query: String, h: Map<String, String>, body: ByteArray) {
        if (method == "GET" && path == "/api/ping") {
            respond(out, 200, PingResponse(deviceName()))
            return
        }
        if (!tokenOk(h["x-token"])) {
            respond(out, 401, SimpleResult(false, "رمز الاقتران غير صحيح"))
            return
        }
        fun text() = body.toString(Charsets.UTF_8)
        when {
            method == "GET" && path == "/api/status" -> respond(out, 200, handler.status())
            method == "POST" && path == "/api/command" ->
                respond(out, 200, handler.command(ControlJson.decodeFromString<CommandRequest>(text()).action))
            method == "GET" && path == "/api/settings" -> respond(out, 200, handler.getSettings())
            method == "POST" && path == "/api/settings" ->
                respond(out, 200, handler.updateSettings(ControlJson.decodeFromString<AppSettings>(text())))
            method == "POST" && path == "/api/keys" ->
                respond(out, 200, handler.updateKeys(ControlJson.decodeFromString<KeysUpdate>(text())))
            method == "GET" && path == "/api/history" -> {
                val limit = query.split('&').firstOrNull { it.startsWith("limit=") }
                    ?.substringAfter('=')?.toIntOrNull()?.coerceIn(1, 200) ?: 50
                respond(out, 200, handler.history(limit))
            }
            method == "DELETE" && path == "/api/history" -> respond(out, 200, handler.clearHistory())
            method == "POST" && path == "/api/text" ->
                respond(out, 200, handler.submitText(ControlJson.decodeFromString<TextSubmission>(text()).lines))
            method == "POST" && path == "/api/frame" -> respond(out, 200, handler.submitFrame(body))
            method == "POST" && path == "/api/test" -> respond(out, 200, handler.runTest())
            else -> respond(out, 404, SimpleResult(false, "المسار غير موجود"))
        }
    }

    private inline fun <reified T> respond(out: OutputStream, code: Int, value: T) {
        val payload = ControlJson.encodeToString(value).toByteArray(Charsets.UTF_8)
        val reason = when (code) { 200 -> "OK"; 400 -> "Bad Request"; 401 -> "Unauthorized"; 404 -> "Not Found"; 413 -> "Payload Too Large"; else -> "Error" }
        val head = "HTTP/1.1 $code $reason\r\nContent-Type: application/json; charset=utf-8\r\n" +
            "Content-Length: ${payload.size}\r\nConnection: close\r\n\r\n"
        out.write(head.toByteArray(Charsets.US_ASCII))
        out.write(payload)
        out.flush()
    }

    companion object {
        const val MAX_BODY = 12 * 1024 * 1024
    }
}

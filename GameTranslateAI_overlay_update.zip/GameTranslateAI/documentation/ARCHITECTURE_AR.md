# البنية التقنية

```
مصدر الصورة/النص          التلفاز (android-tv + shared)                    العرض
 ├ PC bridge  ─POST /api/frame──┐
 ├ الهاتف (صورة) ──────────────┤→ LocalControlServer → TranslationEngine
 └ الهاتف/أدوات (نص) /api/text ─┘      │
                                       ├ FrameOcr (ML Kit، اقتصاص المنطقة)
                                       ├ TextChangeDetector (تجاهل المكرر/اهتزاز OCR)
                                       ├ TranslationCache (LRU) + SessionMemory + Glossary
                                       ├ TranslationProvider: Gemini | OpenAI-compat | Demo
                                       └ HistoryStore (Room)
                          EngineState (StateFlow) → شاشة التلفاز / ردّ للجسر / حالة للهاتف
```

- `shared/core`: المنطق (بلا اعتماد على Android) — قابل للاختبار على JVM.
- `shared/net`: خادم HTTP صغير (`LocalControlServer`) وعميل (`TvClient`) واكتشاف NSD.
- `shared/translate`: المزودون والـ prompt والمحلل.
- `shared/ui`: الثيم والمكونات (أزرار متوافقة مع الريموت).

## واجهة الشبكة (رمز PIN في ترويسة `X-Token`)
| الطريقة | المسار | الوظيفة |
|---|---|---|
| GET | /api/ping | اسم الجهاز (بلا رمز) |
| GET | /api/status | الحالة والقياسات |
| POST | /api/command | `{"action":"start|stop|pause|resume"}` |
| GET/POST | /api/settings | الإعدادات |
| POST | /api/keys | `{"geminiKey":"..","openAiKey":".."}` |
| GET/DELETE | /api/history?limit=50 | السجل |
| POST | /api/text | `{"lines":[".."]}` |
| POST | /api/frame | جسم الطلب = صورة JPEG/PNG |
| POST | /api/test | ترجمة تجريبية |

## إضافة مزود ترجمة جديد
نفّذ `TranslationProvider` ثم أضفه في `TranslationEngine.providerFor` وفي `ProviderType`.

## إضافة مصدر إدخال جديد
أي مصدر يستدعي `/api/frame` أو `/api/text` (أو `engine.submitFrame/submitLines` مباشرة). التعرف الصوتي مستقبلاً يحوّل الصوت إلى نص ويستدعي `submitLines`.

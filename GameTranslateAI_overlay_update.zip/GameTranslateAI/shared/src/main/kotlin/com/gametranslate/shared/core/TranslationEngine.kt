package com.gametranslate.shared.core

import com.gametranslate.shared.model.*
import com.gametranslate.shared.translate.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import okhttp3.OkHttpClient

data class EngineState(
    val running: Boolean = false,
    val paused: Boolean = false,
    val subtitle: String = "",
    val lastError: String? = null,
    val notice: String? = null,
    val metrics: Metrics = Metrics()
)

/**
 * قلب النظام. يستقبل نصاً أو صوراً (من الهاتف أو الكمبيوتر) ويعيد الترجمة.
 * إطار واحد يُعالج في كل مرة؛ الإطارات التي تصل أثناء المعالجة تُتجاهل للحفاظ على أقل تأخير.
 */
class TranslationEngine(
    private val scope: CoroutineScope,
    private val repo: SettingsRepository,
    private val ocr: FrameOcr?,
    private val historyStore: HistoryStore,
    private val demoFrame: ((List<String>) -> ByteArray)? = null,
    private val http: OkHttpClient = OkHttpClient(),
    private val providerFactory: ((AppSettings, ApiKeys) -> TranslationProvider)? = null,
    val pipeline: TranslationPipeline = TranslationPipeline()
) {
    private val _state = MutableStateFlow(EngineState())
    val state: StateFlow<EngineState> = _state.asStateFlow()

    private val _history = MutableStateFlow<List<TranslationItem>>(emptyList())
    val history: StateFlow<List<TranslationItem>> = _history.asStateFlow()

    private val busy = Mutex()
    private var demoIndex = 0
    private val demoSets = listOf(
        listOf("New Game", "Continue", "Settings"),
        listOf("Kratos: We must leave before dawn."),
        listOf("Quest: Find the lost sword", "Press X to continue")
    )

    init {
        scope.launch {
            runCatching {
                val old = historyStore.recent(500)
                _history.value = old.take(200)
                old.asReversed().forEach { if (it.pair.isNotEmpty()) pipeline.cache.put(it.pair, it.source, it.translated) }
            }
        }
    }

    fun start() {
        pipeline.detector.reset()
        _state.update { it.copy(running = true, paused = false, lastError = null) }
    }

    fun stop() {
        pipeline.detector.reset()
        pipeline.memory.clear()
        _state.update { it.copy(running = false, paused = false) }
    }

    fun pause() { if (_state.value.running) _state.update { it.copy(paused = true) } }
    fun resume() { if (_state.value.running) _state.update { it.copy(paused = false) } }

    suspend fun clearHistory() {
        historyStore.clear()
        _history.value = emptyList()
    }

    fun status(deviceName: String, version: String = APP_VERSION): EngineStatus {
        val s = repo.settings.value
        val k = repo.keys()
        val st = _state.value
        val hasKey = when (s.provider) {
            ProviderType.GEMINI -> k.gemini.isNotBlank()
            ProviderType.OPENAI -> k.openAi.isNotBlank()
            ProviderType.DEMO -> false
        }
        return EngineStatus(
            running = st.running, paused = st.paused, provider = s.provider, hasApiKey = hasKey,
            lastError = st.lastError, notice = st.notice, metrics = st.metrics,
            subtitle = st.subtitle, deviceName = deviceName, version = version
        )
    }

    private fun providerFor(s: AppSettings, k: ApiKeys): Pair<TranslationProvider, String?> {
        providerFactory?.let { return it(s, k) to null }
        return when (s.provider) {
            ProviderType.DEMO -> DemoProvider to null
            ProviderType.GEMINI ->
                if (k.gemini.isBlank()) DemoProvider to "لا يوجد مفتاح Gemini — يعمل الوضع التجريبي"
                else GeminiProvider({ repo.keys().gemini }, { repo.settings.value.geminiModel }, http) to null
            ProviderType.OPENAI ->
                if (k.openAi.isBlank()) DemoProvider to "لا يوجد مفتاح API — يعمل الوضع التجريبي"
                else OpenAiProvider(
                    { repo.keys().openAi }, { repo.settings.value.openAiBaseUrl },
                    { repo.settings.value.openAiModel }, http
                ) to null
        }
    }

    private fun gate(): SimpleResult? {
        val st = _state.value
        return if (!st.running || st.paused) SimpleResult(false, "الترجمة متوقفة أو في وضع الإيقاف المؤقت") else null
    }

    suspend fun submitLines(lines: List<String>): SimpleResult {
        gate()?.let { return it }
        if (!busy.tryLock()) return SimpleResult(false, "المعالج مشغول — تم تجاهل الطلب")
        try {
            return handle(lines, 0, System.nanoTime())
        } finally {
            busy.unlock()
        }
    }

    suspend fun submitFrame(image: ByteArray): SimpleResult {
        gate()?.let { return it }
        val engineOcr = ocr ?: return SimpleResult(false, "OCR غير متاح على هذا الجهاز")
        if (!busy.tryLock()) return SimpleResult(false, "المعالج مشغول — تم تجاهل الإطار")
        try {
            val t0 = System.nanoTime()
            val lines = try {
                engineOcr.recognize(image, repo.settings.value.region)
            } catch (e: Exception) {
                _state.update { it.copy(lastError = "فشل قراءة النص من الصورة (OCR)") }
                return SimpleResult(false, "فشل OCR")
            }
            val ocrMs = (System.nanoTime() - t0) / 1_000_000
            return handle(lines, ocrMs, t0)
        } finally {
            busy.unlock()
        }
    }

    /** نافذة الاختبار: تُنتج صورة تجريبية، تقرؤها بـ OCR، وتترجمها بالوضع التجريبي دون الحاجة لمفتاح. */
    suspend fun runDemo(): SimpleResult {
        if (!busy.tryLock()) return SimpleResult(false, "المعالج مشغول")
        try {
            pipeline.detector.reset()
            val t0 = System.nanoTime()
            val lines = demoSets[demoIndex++ % demoSets.size]
            var input = lines
            var ocrMs = 0L
            val engineOcr = ocr
            val frame = demoFrame
            if (engineOcr != null && frame != null) {
                val a = System.nanoTime()
                input = try {
                    val bytes = withContext(Dispatchers.Default) { frame(lines) }
                    engineOcr.recognize(bytes, RegionPreset.FULL)
                } catch (e: Exception) { lines }
                ocrMs = (System.nanoTime() - a) / 1_000_000
                if (input.isEmpty()) input = lines
            }
            return handle(input, ocrMs, t0, forceDemo = true)
        } finally {
            busy.unlock()
        }
    }

    private suspend fun handle(lines: List<String>, ocrMs: Long, t0: Long, forceDemo: Boolean = false): SimpleResult {
        val s = repo.settings.value
        val (provider, notice) = if (forceDemo) DemoProvider to null else providerFor(s, repo.keys())
        return try {
            val r = pipeline.process(lines, s, provider, ocrMs)
            if (r.items.isEmpty()) {
                SimpleResult(true, "لا يوجد نص جديد", null, r.metrics)
            } else {
                val text = r.items.joinToString("\n") { it.translated }
                val m = r.metrics.copy(totalMs = (System.nanoTime() - t0) / 1_000_000)
                _state.update { it.copy(subtitle = text, lastError = null, notice = notice, metrics = m) }
                _history.update { (r.items.asReversed() + it).take(200) }
                scope.launch { runCatching { historyStore.add(r.items) } }
                SimpleResult(true, "تمت الترجمة", text, m)
            }
        } catch (e: TranslationException) {
            _state.update { it.copy(lastError = e.message, notice = notice) }
            SimpleResult(false, e.message ?: "خطأ في الترجمة")
        }
    }
}

package com.gametranslate.mobile

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.gametranslate.shared.model.ProviderType
import com.gametranslate.shared.ui.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MobileRoot(vm: MobileViewModel) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val toast by vm.toast.collectAsState()
    val snack = remember { SnackbarHostState() }
    LaunchedEffect(toast) {
        toast?.let { snack.showSnackbar(it); vm.consumeToast() }
    }
    val tabs = listOf("🎮" to S.home, "⚙️" to S.settings, "🕘" to S.history, "📡" to S.connection)
    Scaffold(
        containerColor = Color.Transparent,
        snackbarHost = { SnackbarHost(snack) },
        bottomBar = {
            NavigationBar(containerColor = GameColors.Surface) {
                tabs.forEachIndexed { i, (icon, label) ->
                    NavigationBarItem(
                        selected = tab == i, onClick = { tab = i },
                        icon = { Text(icon, fontSize = 20.sp) },
                        label = { Text(label, fontSize = 11.sp) },
                        colors = NavigationBarItemDefaults.colors(indicatorColor = GameColors.Surface2)
                    )
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                0 -> ControlTab(vm) { tab = 3 }
                1 -> SettingsTab(vm)
                2 -> HistoryTab(vm)
                else -> ConnectionTab(vm)
            }
        }
    }
}

@Composable
private fun ConnChip(vm: MobileViewModel) {
    val conn by vm.conn.collectAsState()
    when (conn.kind) {
        ConnKind.CONNECTED -> StatusChip("متصل: ${conn.message}", GameColors.Success)
        ConnKind.CONNECTING -> StatusChip("جارٍ الاتصال...", GameColors.Warning)
        ConnKind.FAILED -> StatusChip("فشل الاتصال", GameColors.Error)
        ConnKind.DISCONNECTED -> StatusChip("غير متصل", GameColors.Muted)
    }
}

@Composable
private fun NotConnected(go: () -> Unit) {
    GameCard(title = "غير متصل بالتلفاز") {
        Text("اتصل بالتلفاز أولاً من تبويب الاتصال.", color = GameColors.Muted)
        GameButton("الذهاب إلى الاتصال", go, modifier = Modifier.fillMaxWidth())
    }
}

@Composable
private fun ControlTab(vm: MobileViewModel, goConnection: () -> Unit) {
    val conn by vm.conn.collectAsState()
    val status by vm.status.collectAsState()
    val settings by vm.settings.collectAsState()
    var text by remember { mutableStateOf("") }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? -> uri?.let { vm.sendImage(it) } }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text(S.app, color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
        ConnChip(vm)
        val st = status
        if (conn.kind != ConnKind.CONNECTED || st == null) {
            NotConnected(goConnection)
            return@Column
        }
        GameCard(title = "حالة الترجمة") {
            when {
                st.running && st.paused -> StatusChip(S.paused, GameColors.Warning)
                st.running -> StatusChip(S.running, GameColors.Success)
                else -> StatusChip(S.stopped, GameColors.Muted)
            }
            val providerName = when (st.provider) { ProviderType.DEMO -> "تجريبي"; ProviderType.GEMINI -> "Gemini"; ProviderType.OPENAI -> "OpenAI-compatible" }
            Text("المحرك: $providerName", color = GameColors.Text)
            st.lastError?.let { Text("⚠ $it", color = GameColors.Error) }
            st.notice?.let { Text("ℹ $it", color = GameColors.Warning) }
            if (st.subtitle.isNotBlank()) settings?.let { SubtitleBox(it, st.subtitle, Modifier.fillMaxWidth()) }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
            if (!st.running) GameButton(S.start, { vm.command("start") }, Modifier.weight(1f))
            else GameButton(S.stop, { vm.command("stop") }, Modifier.weight(1f))
            if (st.running) {
                if (st.paused) GameButton(S.resume, { vm.command("resume") }, Modifier.weight(1f), primary = false)
                else GameButton(S.pause, { vm.command("pause") }, Modifier.weight(1f), primary = false)
            }
        }
        GameButton("اختبار ترجمة تجريبية على التلفاز", { vm.runTest() }, Modifier.fillMaxWidth(), primary = false)
        MetricsCard(st.metrics)
        GameCard(title = "إرسال نص أو صورة للترجمة") {
            OutlinedTextField(
                text, { text = it }, label = { Text("نص إنجليزي (سطر لكل جملة)") }, minLines = 2,
                textStyle = TextStyle(textDirection = TextDirection.Ltr), modifier = Modifier.fillMaxWidth()
            )
            GameButton("ترجمة النص", { vm.sendText(text) }, Modifier.fillMaxWidth(), enabled = text.isNotBlank() && st.running && !st.paused)
            GameButton("إرسال صورة من المعرض (OCR على التلفاز)", { picker.launch("image/*") }, Modifier.fillMaxWidth(), primary = false, enabled = st.running && !st.paused)
            Text("يجب أن تكون الترجمة قيد التشغيل (غير متوقفة) لاستقبال النصوص والصور.", color = GameColors.Muted, fontSize = 12.sp)
        }
    }
}

@Composable
private fun SettingsTab(vm: MobileViewModel) {
    val settings by vm.settings.collectAsState()
    val status by vm.status.collectAsState()
    var gKey by remember { mutableStateOf("") }
    var oKey by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text(S.settings, color = GameColors.PurpleLight, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
        val s = settings
        if (s == null) {
            GameCard { Text("اتصل بالتلفاز لتعديل الإعدادات.", color = GameColors.Muted) }
            return@Column
        }
        SubtitleBox(s, "معاينة: مرحباً بك في عالم اللعبة", Modifier.fillMaxWidth())
        SettingsPanel(s, { n -> vm.updateSettings { n } }, advanced = true)
        GameCard(title = "مفاتيح API (تُخزَّن مشفّرة على التلفاز)") {
            val has = status?.hasApiKey == true
            Text(if (has) "✔ يوجد مفتاح محفوظ للمحرك المختار" else "لا يوجد مفتاح للمحرك المختار — يعمل الوضع التجريبي", color = if (has) GameColors.Success else GameColors.Warning, fontSize = 14.sp)
            OutlinedTextField(
                gKey, { gKey = it }, label = { Text("Gemini API Key") }, singleLine = true,
                visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                textStyle = TextStyle(textDirection = TextDirection.Ltr), modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                oKey, { oKey = it }, label = { Text("OpenAI-compatible API Key") }, singleLine = true,
                visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                textStyle = TextStyle(textDirection = TextDirection.Ltr), modifier = Modifier.fillMaxWidth()
            )
            GameButton("إرسال المفتاح إلى التلفاز", { vm.sendKeys(gKey, oKey); gKey = ""; oKey = "" }, Modifier.fillMaxWidth(), enabled = gKey.isNotBlank() || oKey.isNotBlank())
            Text("المفتاح لا يُحفظ على الهاتف. يُرسل عبر شبكتك المحلية بـ HTTP غير مشفّر، فاستخدم شبكة منزلية موثوقة.", color = GameColors.Muted, fontSize = 12.sp)
        }
    }
}

@Composable
private fun HistoryTab(vm: MobileViewModel) {
    val list by vm.history.collectAsState()
    LaunchedEffect(Unit) { vm.refreshHistory() }
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(S.history, color = GameColors.PurpleLight, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            GameButton("تحديث", { vm.refreshHistory() }, primary = false)
            GameButton(S.clearHistory, { vm.clearHistory() }, primary = false)
        }
        HistoryList(list, Modifier.weight(1f))
    }
}

@Composable
private fun ConnectionTab(vm: MobileViewModel) {
    val conn by vm.conn.collectAsState()
    val found by vm.discovered.collectAsState()
    var host by remember { mutableStateOf(vm.savedHost) }
    var port by remember { mutableStateOf(vm.savedPort.toString()) }
    var pin by remember { mutableStateOf(vm.savedPin) }
    DisposableEffect(Unit) {
        vm.startDiscovery()
        onDispose { vm.stopDiscovery() }
    }
    val ltr = TextStyle(textDirection = TextDirection.Ltr)
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text(S.connection, color = GameColors.PurpleLight, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
        ConnChip(vm)
        if (conn.kind == ConnKind.FAILED) Text(conn.message, color = GameColors.Error, fontSize = 14.sp)
        GameCard(title = "أجهزة تلفاز مكتشفة تلقائياً") {
            if (found.isEmpty()) Text("جارٍ البحث... (إن لم يظهر شيء أدخل العنوان يدوياً)", color = GameColors.Muted, fontSize = 14.sp)
            found.forEach { tv -> GameButton("${tv.name} — ${tv.host}", { host = tv.host; port = tv.port.toString() }, Modifier.fillMaxWidth(), primary = false) }
        }
        GameCard(title = "بيانات التلفاز") {
            OutlinedTextField(host, { host = it }, label = { Text("عنوان التلفاز (IP)") }, singleLine = true, textStyle = ltr,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri), modifier = Modifier.fillMaxWidth())
            OutlinedTextField(port, { port = it.filter(Char::isDigit) }, label = { Text("المنفذ") }, singleLine = true, textStyle = ltr,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
            OutlinedTextField(pin, { pin = it.filter(Char::isDigit).take(6) }, label = { Text(S.pin) }, singleLine = true, textStyle = ltr,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword), modifier = Modifier.fillMaxWidth())
            GameButton("اتصال", { vm.connect(host, port.toIntOrNull() ?: 8765, pin) }, Modifier.fillMaxWidth(),
                enabled = host.isNotBlank() && pin.length == 6 && conn.kind != ConnKind.CONNECTING)
            if (conn.kind == ConnKind.CONNECTED) GameButton("قطع الاتصال", { vm.disconnect() }, Modifier.fillMaxWidth(), primary = false)
        }
        GameCard(title = "كيف أجد العنوان والرمز؟") {
            Text("على التلفاز: افتح التطبيق ← الاتصال. سيظهر العنوان والمنفذ والرمز المكوّن من 6 أرقام.", color = GameColors.Text, fontSize = 14.sp)
        }
    }
}

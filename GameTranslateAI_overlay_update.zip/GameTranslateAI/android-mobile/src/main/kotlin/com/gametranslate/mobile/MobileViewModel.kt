package com.gametranslate.mobile

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.gametranslate.shared.data.SecureStore
import com.gametranslate.shared.model.*
import com.gametranslate.shared.net.DiscoveredTv
import com.gametranslate.shared.net.Nsd
import com.gametranslate.shared.net.TvClient
import com.gametranslate.shared.net.TvClientException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

enum class ConnKind { DISCONNECTED, CONNECTING, CONNECTED, FAILED }
data class Conn(val kind: ConnKind, val message: String = "")

class MobileViewModel(app: Application) : AndroidViewModel(app) {
    private val secure = SecureStore(app)
    private val prefs = app.getSharedPreferences("connection", 0)

    private val _conn = MutableStateFlow(Conn(ConnKind.DISCONNECTED))
    val conn: StateFlow<Conn> = _conn
    private val _status = MutableStateFlow<EngineStatus?>(null)
    val status: StateFlow<EngineStatus?> = _status
    private val _settings = MutableStateFlow<AppSettings?>(null)
    val settings: StateFlow<AppSettings?> = _settings
    private val _history = MutableStateFlow<List<TranslationItem>>(emptyList())
    val history: StateFlow<List<TranslationItem>> = _history
    private val _discovered = MutableStateFlow<List<DiscoveredTv>>(emptyList())
    val discovered: StateFlow<List<DiscoveredTv>> = _discovered
    private val _toast = MutableStateFlow<String?>(null)
    val toast: StateFlow<String?> = _toast

    val savedHost: String get() = prefs.getString("host", "") ?: ""
    val savedPort: Int get() = prefs.getInt("port", DEFAULT_PORT)
    val savedPin: String get() = secure.get("token")

    private var client: TvClient? = null
    private var pollJob: Job? = null
    private var discovery: Nsd.Discovery? = null

    init {
        if (savedHost.isNotBlank() && savedPin.isNotBlank()) connect(savedHost, savedPort, savedPin)
    }

    fun consumeToast() { _toast.value = null }
    private fun say(msg: String) { _toast.value = msg }

    fun connect(host: String, port: Int, pin: String) {
        pollJob?.cancel()
        viewModelScope.launch {
            _conn.value = Conn(ConnKind.CONNECTING)
            val c = TvClient(host.trim(), pin.trim(), port)
            try {
                val ping = c.ping()
                val st = c.status() // يتحقق من رمز الاقتران
                client = c
                prefs.edit().putString("host", c.host).putInt("port", port).apply()
                secure.put("token", c.token)
                _status.value = st
                _settings.value = c.getSettings()
                _history.value = c.history(100)
                _conn.value = Conn(ConnKind.CONNECTED, ping.name)
                startPolling(c)
            } catch (e: TvClientException) {
                client = null
                _conn.value = Conn(ConnKind.FAILED, e.message ?: "فشل الاتصال")
            }
        }
    }

    fun disconnect() {
        pollJob?.cancel()
        client = null
        _status.value = null
        _settings.value = null
        secure.put("token", "")
        _conn.value = Conn(ConnKind.DISCONNECTED)
    }

    private fun startPolling(c: TvClient) {
        pollJob?.cancel()
        pollJob = viewModelScope.launch {
            var fails = 0
            while (isActive) {
                try {
                    _status.value = c.status()
                    fails = 0
                } catch (e: TvClientException) {
                    if (++fails >= 3) {
                        _conn.value = Conn(ConnKind.FAILED, "انقطع الاتصال بالتلفاز")
                        client = null
                        break
                    }
                }
                delay(2000)
            }
        }
    }

    private fun act(block: suspend (TvClient) -> SimpleResult?) {
        viewModelScope.launch {
            val c = client ?: run { say("غير متصل بالتلفاز"); return@launch }
            try {
                block(c)?.let { say(it.subtitle ?: it.message) }
                _status.value = c.status()
            } catch (e: TvClientException) {
                say(e.message ?: "خطأ")
            }
        }
    }

    fun command(action: String) = act { it.command(action) }
    fun runTest() = act { it.runTest() }

    fun sendText(text: String) {
        val lines = text.lines().map { it.trim() }.filter { it.isNotEmpty() }
        if (lines.isEmpty()) return
        act { it.sendText(lines) }
    }

    fun sendImage(uri: Uri) {
        viewModelScope.launch {
            val bytes = withContext(Dispatchers.IO) {
                runCatching { getApplication<Application>().contentResolver.openInputStream(uri)?.use { it.readBytes() } }.getOrNull()
            }
            when {
                bytes == null -> say("تعذر قراءة الصورة")
                bytes.size > 10 * 1024 * 1024 -> say("الصورة كبيرة (الحد 10MB)")
                else -> act { it.sendFrame(bytes) }
            }
        }
    }

    fun updateSettings(transform: (AppSettings) -> AppSettings) {
        val n = transform(_settings.value ?: return)
        _settings.value = n
        act { it.updateSettings(n) }
    }

    fun sendKeys(gemini: String, openAi: String) =
        act { it.updateKeys(KeysUpdate(gemini.ifBlank { null }, openAi.ifBlank { null })) }

    fun refreshHistory() {
        viewModelScope.launch {
            try { _history.value = client?.history(100) ?: emptyList() } catch (e: TvClientException) { say(e.message ?: "خطأ") }
        }
    }

    fun clearHistory() {
        act { it.clearHistory() }
        _history.value = emptyList()
    }

    fun startDiscovery() {
        if (discovery != null) return
        _discovered.value = emptyList()
        discovery = Nsd.Discovery(
            getApplication<Application>(),
            onFound = { tv -> _discovered.update { list -> list.filter { it.host != tv.host } + tv } },
            onLost = { name -> _discovered.update { list -> list.filter { it.name != name } } }
        ).also { it.start() }
    }

    fun stopDiscovery() {
        discovery?.stop()
        discovery = null
    }

    override fun onCleared() {
        stopDiscovery()
        pollJob?.cancel()
    }
}

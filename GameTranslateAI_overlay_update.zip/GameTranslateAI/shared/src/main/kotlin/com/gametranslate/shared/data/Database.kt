package com.gametranslate.shared.data

import android.content.Context
import androidx.room.*
import com.gametranslate.shared.core.HistoryStore
import com.gametranslate.shared.model.TranslationItem

@Entity(tableName = "history")
data class HistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val source: String,
    val translated: String,
    val fromCache: Boolean,
    val timestamp: Long,
    val pair: String
)

@Dao
interface HistoryDao {
    @Insert suspend fun insertAll(items: List<HistoryEntity>)

    @Query("SELECT * FROM history ORDER BY id DESC LIMIT :limit")
    suspend fun recent(limit: Int): List<HistoryEntity>

    @Query("DELETE FROM history")
    suspend fun clear()

    @Query("DELETE FROM history WHERE id NOT IN (SELECT id FROM history ORDER BY id DESC LIMIT 2000)")
    suspend fun trim()
}

@Database(entities = [HistoryEntity::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun historyDao(): HistoryDao

    companion object {
        fun create(context: Context): AppDatabase =
            Room.databaseBuilder(context.applicationContext, AppDatabase::class.java, "gametranslate.db").build()
    }
}

class RoomHistoryStore(private val dao: HistoryDao) : HistoryStore {
    override suspend fun add(items: List<TranslationItem>) {
        dao.insertAll(items.map { HistoryEntity(source = it.source, translated = it.translated, fromCache = it.fromCache, timestamp = it.timestamp, pair = it.pair) })
        dao.trim()
    }

    override suspend fun recent(limit: Int) =
        dao.recent(limit).map { TranslationItem(it.source, it.translated, it.fromCache, it.timestamp, it.pair) }

    override suspend fun clear() = dao.clear()
}

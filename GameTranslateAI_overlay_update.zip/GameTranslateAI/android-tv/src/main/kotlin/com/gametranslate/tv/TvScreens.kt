package com.gametranslate.tv

import androidx.activity.compose.BackHandler
import androidx.compose.ui.platform.LocalContext
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.gametranslate.shared.model.DEFAULT_PORT
import com.gametranslate.shared.model.SubtitlePosition
import com.gametranslate.shared.net.NetUtil
import com.gametranslate.shared.ui.*
import kotlinx.coroutines.launch

enum class Screen { HOME, SETTINGS, HISTORY, CONNECTION, TEST, LIVE }

@Composable
fun TvRoot(c: TvContainer) {
    var screen by remember { mutableStateOf(Screen.HOME) }
    BackHandler(enabled = screen != Screen.HOME) { screen = Screen.HOME }
    when (screen) {
        Screen.HOME -> HomeScreen(c) { screen = it }
        Screen.SETTINGS -> SettingsScreen(c)
        Screen.HISTORY -> HistoryScreen(c)
        Screen.CONNECTION -> ConnectionScreen(c)
        Screen.TEST -> TestScreen(c)
        Screen.LIVE -> LiveScreen(c)
    }
}

@Composable
private fun Page(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(horizontal = 56.dp, vertical = 36.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        Text(title, color = GameColors.PurpleLight, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
        content()
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun HomeScreen(c: TvContainer, go: (Screen) -> Unit) {
    val state by c.engine.state.collectAsState()
    val settings by c.settings.settings.collectAsState()
    val focus = remember { FocusRequester() }
    val context = LocalContext.current
    LaunchedEffect(Unit) { kotlinx.coroutines.delay(200); runCatching { focus.requestFocus() } }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 56.dp, vertical = 36.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column {
                Text(S.app, color = Color.White, fontSize = 42.sp, fontWeight = FontWeight.ExtraBold)
                Text(S.tagline, color = GameColors.Muted, fontSize = 18.sp)
            }
            when {
                state.running && state.paused -> StatusChip(S.paused, GameColors.Warning)
                state.running -> StatusChip(S.running, GameColors.Success)
                else -> StatusChip(S.stopped, GameColors.Muted)
            }
        }
        state.lastError?.let { GameCard { Text("⚠ $it", color = GameColors.Error, fontSize = 16.sp) } }
        state.notice?.let { GameCard { Text("ℹ $it", color = GameColors.Warning, fontSize = 16.sp) } }

        FlowRow(horizontalArrangement = Arrangement.spacedBy(14.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            if (!state.running) GameButton(S.start, { c.engine.start() }, focusRequester = focus)
            else GameButton(S.stop, { c.engine.stop() }, focusRequester = focus)
            if (state.running) {
                if (state.paused) GameButton(S.resume, { c.engine.resume() }, primary = false)
                else GameButton(S.pause, { c.engine.pause() }, primary = false)
            }
            GameButton(S.live, { go(Screen.LIVE) }, primary = false)
            GameButton(S.test, { go(Screen.TEST) }, primary = false)
            GameButton(S.settings, { go(Screen.SETTINGS) }, primary = false)
            GameButton(S.history, { go(Screen.HISTORY) }, primary = false)
            GameButton("تفعيل الترجمة فوق HDMI", {
                if (Settings.canDrawOverlays(context)) {
                    context.startService(Intent(context, OverlaySubtitleService::class.java))
                } else {
                    val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${context.packageName}"))
                    context.startActivity(intent)
                }
            }, primary = false)
            GameButton(S.connection, { go(Screen.CONNECTION) }, primary = false)
        }
        MetricsCard(state.metrics)
        if (state.subtitle.isNotBlank()) SubtitleBox(settings, state.subtitle, Modifier.fillMaxWidth())
    }
}

@Composable
private fun SettingsScreen(c: TvContainer) {
    val settings by c.settings.settings.collectAsState()
    Page(S.settings) {
        Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(18.dp)) {
            SubtitleBox(settings, "مرحباً بك في عالم اللعبة", Modifier.fillMaxWidth())
            SettingsPanel(settings, { n -> c.settings.update { n } }, advanced = false)
            GameCard {
                Text("مفاتيح API والمعجم وأسماء النماذج تُدخل من تطبيق الهاتف (الكتابة بالريموت صعبة).", color = GameColors.Muted, fontSize = 15.sp)
            }
        }
    }
}

@Composable
private fun HistoryScreen(c: TvContainer) {
    val list by c.engine.history.collectAsState()
    val scope = rememberCoroutineScope()
    Page(S.history) {
        GameButton(S.clearHistory, { scope.launch { c.engine.clearHistory() } }, primary = false)
        HistoryList(list, Modifier.weight(1f))
    }
}

@Composable
private fun ConnectionScreen(c: TvContainer) {
    val pin by c.pin.collectAsState()
    val err by c.serverError.collectAsState()
    val ip = remember { NetUtil.localIpv4() ?: "غير متاح (تأكد من الاتصال بالشبكة)" }
    Page(S.connection) {
        Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            err?.let { GameCard { Text(it, color = GameColors.Error) } }
            GameCard(title = "بيانات الاتصال بالهاتف") {
                Text("عنوان التلفاز:  $ip", color = Color.White, fontSize = 22.sp)
                Text("المنفذ:  $DEFAULT_PORT", color = Color.White, fontSize = 22.sp)
                Text("${S.pin}:  $pin", color = GameColors.PurpleLight, fontSize = 34.sp, fontWeight = FontWeight.ExtraBold)
                GameButton("توليد رمز جديد", { c.regeneratePin() }, primary = false)
            }
            GameCard(title = "الخطوات") {
                Text("١) افتح تطبيق GameTranslate على الهاتف (نفس شبكة الواي فاي).", color = GameColors.Text, fontSize = 16.sp)
                Text("٢) اختر التلفاز من القائمة أو اكتب العنوان أعلاه، ثم أدخل الرمز.", color = GameColors.Text, fontSize = 16.sp)
                Text("٣) يجب إبقاء هذا التطبيق مفتوحاً على التلفاز أثناء الاستخدام.", color = GameColors.Text, fontSize = 16.sp)
            }
        }
    }
}

@Composable
private fun TestScreen(c: TvContainer) {
    val state by c.engine.state.collectAsState()
    val settings by c.settings.settings.collectAsState()
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { kotlinx.coroutines.delay(200); runCatching { focus.requestFocus() } }
    Page(S.test) {
        Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            Text(
                "ينشئ صورة اختبار بنص إنجليزي، يقرؤها OCR حقيقي، ثم يترجمها بالقاموس التجريبي المدمج (لا يحتاج مفتاحاً).",
                color = GameColors.Muted, fontSize = 15.sp
            )
            GameButton(if (busy) "جارٍ التشغيل..." else "تشغيل ترجمة تجريبية", {
                scope.launch { busy = true; c.engine.runDemo(); busy = false }
            }, enabled = !busy, focusRequester = focus)
            SubtitleBox(settings, state.subtitle.ifBlank { "اضغط الزر لعرض ترجمة تجريبية" }, Modifier.fillMaxWidth())
            MetricsCard(state.metrics)
            state.lastError?.let { Text(it, color = GameColors.Error) }
        }
    }
}

@Composable
private fun LiveScreen(c: TvContainer) {
    val state by c.engine.state.collectAsState()
    val settings by c.settings.settings.collectAsState()
    val align = when (settings.position) {
        SubtitlePosition.TOP -> Alignment.TopCenter
        SubtitlePosition.CENTER -> Alignment.Center
        SubtitlePosition.BOTTOM -> Alignment.BottomCenter
    }
    val liveFocus = remember { FocusRequester() }
    LaunchedEffect(Unit) { kotlinx.coroutines.delay(200); runCatching { liveFocus.requestFocus() } }
    Box(
        Modifier.fillMaxSize().background(Color.Black).focusRequester(liveFocus)
            .clickable { if (state.paused) c.engine.resume() else c.engine.pause() }
    ) {
        Row(Modifier.align(Alignment.TopStart).padding(24.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            when {
                state.running && state.paused -> StatusChip(S.paused, GameColors.Warning)
                state.running -> StatusChip(S.running, GameColors.Success)
                else -> StatusChip(S.stopped, GameColors.Muted)
            }
            Text("زر الموافقة: إيقاف مؤقت/استئناف  •  رجوع: خروج", color = GameColors.Muted, fontSize = 13.sp)
        }
        Crossfade(targetState = state.subtitle, modifier = Modifier.align(align).padding(48.dp), label = "subtitle") { text ->
            if (text.isNotBlank()) SubtitleBox(settings, text, Modifier.fillMaxWidth())
            else Text("بانتظار نص من اللعبة...", color = GameColors.Muted, fontSize = 20.sp)
        }
    }
}

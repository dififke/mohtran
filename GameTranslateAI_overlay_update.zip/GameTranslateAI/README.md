# GameTranslate AI — ترجمة ألعاب PS5 إلى العربية بالذكاء الاصطناعي

مشروع من تطبيقين مستقلين يتواصلان عبر الشبكة المحلية:

| التطبيق | الدور |
|---|---|
| **android-tv** | يعمل على Android TV: يستقبل النص/الصور، يقرأ النص (OCR)، يترجمه، ويعرضه بإعداداتك |
| **android-mobile** | الريموت الذكي: تحكم، إعدادات، مفاتيح API، سجل الترجمات |
| **shared** | الكود المشترك: OCR، الترجمة (Gemini/OpenAI)، الـ Cache، الاتصال، الواجهة |
| **scripts/pc_bridge.py** | جسر الكمبيوتر: يلتقط شاشة PS Remote Play ويرسلها للتلفاز |

## ⚠️ حالة المشروع بصراحة

- **كتبتُ الكود كاملاً، لكن لم أستطع بناءه أو تشغيل اختباراته في البيئة التي أنشأته فيها** (لا يوجد Android SDK ولا إنترنت هناك). لذلك **لا توجد APK جاهزة** في هذا التسليم، وقد تظهر أخطاء بناء صغيرة عند أول مرة.
- الحل لأنك مبتدئ: **GitHub Actions** يبني التطبيقين تلقائياً ويعطيك ملفي APK (الخطوات في [documentation/INSTALL_AR.md](documentation/INSTALL_AR.md)). إن ظهر خطأ، الصق لي نص الخطأ وأصلحه.
- أُضيفت **طبقة ترجمة عائمة تجريبية** لتطبيق Android TV باستخدام صلاحية الظهور فوق التطبيقات. قد تظهر فوق بعض واجهات HDMI، لكن ذلك يعتمد على الشركة المصنّعة وطريقة عرض الفيديو، ولا يمكن ضمانه قبل الاختبار على التلفاز الفعلي. التطبيق لا يلتقط إشارة HDMI نفسها.

## الدليل السريع

1. ابنِ التطبيقين → [INSTALL_AR.md](documentation/INSTALL_AR.md)
2. ثبّت `GameTranslateAI-TV.apk` على التلفاز و`GameTranslateAI-Phone.apk` على الهاتف.
3. افتح تطبيق التلفاز ← "الاتصال" ← سيظهر العنوان والرمز (PIN).
4. افتح تطبيق الهاتف ← تبويب "الاتصال" ← اتصل.
5. من الهاتف: "بدء الترجمة" ثم "اختبار ترجمة تجريبية" (يعمل بدون أي مفتاح).
6. لترجمة حقيقية أضف مفتاح Gemini → [GEMINI_AR.md](documentation/GEMINI_AR.md)
7. لربط PS5 → [PS5_AR.md](documentation/PS5_AR.md)

## الوثائق

- [دليل التثبيت والبناء](documentation/INSTALL_AR.md)
- [إضافة مفتاح Gemini وأمان المفاتيح](documentation/GEMINI_AR.md)
- [ربط PS5 بالنظام](documentation/PS5_AR.md)
- [حدود Android TV الحقيقية](documentation/LIMITS_AR.md)
- [الميزات المكتملة والميزات التي تحتاج معدات](documentation/FEATURES_AR.md)
- [البنية التقنية](documentation/ARCHITECTURE_AR.md)

## هيكل المشروع

```
GameTranslateAI/
├── android-tv/        تطبيق التلفاز
├── android-mobile/    تطبيق الهاتف
├── shared/            الكود المشترك + الاختبارات
├── documentation/     الأدلة بالعربية
├── scripts/           build.sh و pc_bridge.py
├── assets/
├── .github/workflows/build.yml   البناء التلقائي
└── README.md
```

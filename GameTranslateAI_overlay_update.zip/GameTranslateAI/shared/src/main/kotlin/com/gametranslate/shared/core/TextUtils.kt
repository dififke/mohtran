package com.gametranslate.shared.core

object TextUtils {
    private val ws = Regex("\\s+")

    fun normalize(s: String): String = s.replace('\n', ' ').trim().replace(ws, " ")
    fun key(s: String): String = normalize(s).lowercase()

    /** يتجاهل الأرقام والرموز وأجزاء HUD القصيرة جداً. */
    fun isTranslatable(s: String): Boolean {
        val n = normalize(s)
        return n.length >= 2 && n.count { it.isLetter() } >= 2
    }

    fun levenshtein(a: String, b: String): Int {
        if (a == b) return 0
        if (a.isEmpty()) return b.length
        if (b.isEmpty()) return a.length
        var prev = IntArray(b.length + 1) { it }
        var cur = IntArray(b.length + 1)
        for (i in 1..a.length) {
            cur[0] = i
            for (j in 1..b.length) {
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                cur[j] = minOf(cur[j - 1] + 1, prev[j] + 1, prev[j - 1] + cost)
            }
            val t = prev; prev = cur; cur = t
        }
        return prev[b.length]
    }

    fun similarity(a: String, b: String): Double {
        val m = maxOf(a.length, b.length)
        return if (m == 0) 1.0 else 1.0 - levenshtein(a, b).toDouble() / m
    }

    /** صيغة المعجم: كل سطر "term=ترجمة". */
    fun parseGlossary(text: String): Map<String, String> =
        text.lines().mapNotNull { line ->
            val i = line.indexOf('=')
            if (i <= 0) null else {
                val k = line.substring(0, i).trim()
                val v = line.substring(i + 1).trim()
                if (k.isEmpty() || v.isEmpty()) null else k to v
            }
        }.toMap()
}

package com.gametranslate.shared.translate

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException

internal suspend fun OkHttpClient.postJson(url: String, headers: Map<String, String>, body: String): Pair<Int, String> =
    withContext(Dispatchers.IO) {
        try {
            val req = Request.Builder().url(url)
                .apply { headers.forEach { (k, v) -> addHeader(k, v) } }
                .post(body.toRequestBody("application/json; charset=utf-8".toMediaType()))
                .build()
            newCall(req).execute().use { it.code to (it.body?.string().orEmpty()) }
        } catch (e: IOException) {
            throw TranslationException.Network(cause = e)
        } catch (e: IllegalArgumentException) {
            throw TranslationException.Network("عنوان الخادم غير صالح", e)
        }
    }

internal fun checkStatus(code: Int, body: String) {
    when {
        code in 200..299 -> return
        code == 401 || code == 403 || body.contains("API_KEY_INVALID") || body.contains("API key not valid") ->
            throw TranslationException.InvalidKey()
        code == 429 -> throw TranslationException.RateLimited()
        else -> throw TranslationException.BadResponse("خطأ من الخادم (HTTP $code)")
    }
}

package com.gametranslate.shared.translate

import kotlinx.serialization.json.Json
import kotlinx.serialization.json.addJsonObject
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import kotlinx.serialization.json.putJsonArray
import okhttp3.OkHttpClient

/** أي خدمة متوافقة مع واجهة OpenAI (OpenAI, OpenRouter, LM Studio, Ollama ...). */
class OpenAiProvider(
    private val apiKey: () -> String,
    private val baseUrl: () -> String,
    private val model: () -> String,
    private val client: OkHttpClient = OkHttpClient()
) : TranslationProvider {
    override val name = "OpenAI-compatible"

    override suspend fun translate(request: TranslationRequest): List<String> {
        val key = apiKey().trim()
        if (key.isEmpty()) throw TranslationException.MissingKey()
        val body = buildJsonObject {
            put("model", model().trim())
            put("temperature", 0.2)
            putJsonArray("messages") {
                addJsonObject { put("role", "system"); put("content", PromptBuilder.system(request)) }
                addJsonObject { put("role", "user"); put("content", PromptBuilder.user(request)) }
            }
        }.toString()
        val url = baseUrl().trim().trimEnd('/') + "/chat/completions"
        val (code, text) = client.postJson(url, mapOf("Authorization" to "Bearer $key"), body)
        checkStatus(code, text)
        val out = try {
            Json.parseToJsonElement(text).jsonObject["choices"]!!.jsonArray[0].jsonObject["message"]!!
                .jsonObject["content"]!!.jsonPrimitive.content
        } catch (e: Exception) {
            throw TranslationException.BadResponse()
        }
        return ResponseParser.parseArray(out, request.lines.size)
    }
}

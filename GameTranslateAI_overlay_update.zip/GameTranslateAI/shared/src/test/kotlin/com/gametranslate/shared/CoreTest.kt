package com.gametranslate.shared

import com.gametranslate.shared.core.*
import com.gametranslate.shared.model.AppSettings
import com.gametranslate.shared.translate.*
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Test

class CoreTest {
    @Test fun normalizeAndFilter() {
        assertEquals("Hello world", TextUtils.normalize("  Hello \n world "))
        assertFalse(TextUtils.isTranslatable("1234"))
        assertFalse(TextUtils.isTranslatable("X"))
        assertTrue(TextUtils.isTranslatable("Hi"))
    }

    @Test fun glossaryParsing() {
        val g = TextUtils.parseGlossary("Kratos=كريتوس\nbad line\n=x\nAtreus = أتريوس")
        assertEquals(mapOf("Kratos" to "كريتوس", "Atreus" to "أتريوس"), g)
    }

    @Test fun detectorSkipsDuplicatesAndOcrJitter() {
        val d = TextChangeDetector()
        assertEquals(listOf("We must leave before dawn."), d.filterNew(listOf("We must leave before dawn.", "we must leave before dawn.", "123")))
        // اهتزاز OCR: حرف واحد مختلف في جملة طويلة
        assertTrue(d.filterNew(listOf("We must leave before dawn,")).isEmpty())
        assertEquals(listOf("Press X to continue"), d.filterNew(listOf("Press X to continue")))
    }

    @Test fun detectorForgetAllowsRetry() {
        val d = TextChangeDetector()
        d.filterNew(listOf("Hello there"))
        d.forget(listOf("Hello there"))
        assertEquals(listOf("Hello there"), d.filterNew(listOf("Hello there")))
    }

    @Test fun cacheLru() {
        val c = TranslationCache(2)
        c.put("en>ar", "a1", "x"); c.put("en>ar", "b2", "y"); c.put("en>ar", "c3", "z")
        assertNull(c.get("en>ar", "a1"))
        assertEquals("z", c.get("en>ar", "C3"))
    }

    @Test fun parserHandlesFencesAndMismatch() {
        assertEquals(listOf("أ", "ب"), ResponseParser.parseArray("```json\n[\"أ\",\"ب\"]\n```", 2))
        assertEquals(listOf("نص"), ResponseParser.parseArray("نص", 1))
        try { ResponseParser.parseArray("[\"a\"]", 3); fail() } catch (e: TranslationException.BadResponse) { }
    }

    private class CountingProvider : TranslationProvider {
        override val name = "count"
        var calls = 0
        var lastRequest: TranslationRequest? = null
        override suspend fun translate(request: TranslationRequest): List<String> {
            calls++; lastRequest = request
            return request.lines.map { "ت:$it" }
        }
    }

    @Test fun pipelineUsesCacheAndContext() = runBlocking {
        val p = TranslationPipeline()
        val prov = CountingProvider()
        val s = AppSettings()
        val r1 = p.process(listOf("Open the door"), s, prov)
        assertEquals("ت:Open the door", r1.items[0].translated)
        assertEquals(1, prov.calls)
        // نفس النص بعد إعادة ضبط الكاشف يأتي من الـ Cache دون طلب جديد
        p.detector.reset()
        val r2 = p.process(listOf("Open the door"), s, prov)
        assertTrue(r2.items[0].fromCache)
        assertEquals(1, prov.calls)
        // نص جديد يحمل سياق الجلسة
        p.process(listOf("Close the window"), s, prov)
        assertEquals(2, prov.calls)
        assertTrue(prov.lastRequest!!.context.any { it.first == "Open the door" })
    }

    @Test fun pipelineFailureLetsRetry() = runBlocking {
        val p = TranslationPipeline()
        val bad = object : TranslationProvider {
            override val name = "bad"
            override suspend fun translate(request: TranslationRequest): List<String> = throw TranslationException.Network()
        }
        try { p.process(listOf("Hello friend"), AppSettings(), bad); fail() } catch (e: TranslationException.Network) { }
        val ok = p.process(listOf("Hello friend"), AppSettings(), DemoProvider)
        assertEquals(1, ok.items.size)
    }

    @Test fun demoProviderDoesNotPolluteCache() = runBlocking {
        val p = TranslationPipeline()
        p.process(listOf("Unknown phrase here"), AppSettings(), DemoProvider)
        assertEquals(0, p.cache.size())
    }
}

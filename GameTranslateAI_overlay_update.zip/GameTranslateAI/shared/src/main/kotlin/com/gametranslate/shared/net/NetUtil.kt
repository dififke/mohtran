package com.gametranslate.shared.net

import java.net.Inet4Address
import java.net.NetworkInterface

object NetUtil {
    /** عنوان IPv4 المحلي للجهاز (للعرض على شاشة التلفاز). */
    fun localIpv4(): String? = runCatching {
        NetworkInterface.getNetworkInterfaces().toList()
            .filter { it.isUp && !it.isLoopback }
            .flatMap { it.inetAddresses.toList() }
            .filterIsInstance<Inet4Address>()
            .firstOrNull { it.isSiteLocalAddress }
            ?.hostAddress
    }.getOrNull()
}

package com.gametranslate.shared.translate

import kotlinx.serialization.builtins.ListSerializer
import kotlinx.serialization.builtins.serializer
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonArray

object PromptBuilder {
    private val names = mapOf(
        "en" to "English", "ar" to "Arabic", "fr" to "French", "es" to "Spanish",
        "de" to "German", "it" to "Italian", "pt" to "Portuguese"
    )

    fun languageName(code: String) = names[code] ?: code

    fun system(r: TranslationRequest): String = buildString {
        val src = languageName(r.sourceLang)
        val tgt = languageName(r.targetLang)
        appendLine("You are a professional video game localization translator.")
        append("Translate each input string from $src to $tgt.")
        if (r.targetLang == "ar") append(" Use clear Modern Standard Arabic suitable for game subtitles, quests and menus.")
        appendLine()
        appendLine("Rules:")
        appendLine("- Keep character names, place names and item names unchanged unless the glossary says otherwise.")
        appendLine("- Keep terminology consistent with the session context and glossary.")
        appendLine("- Keep controller button names (X, Circle, Square, Triangle, L1, R2...) and numbers as they are.")
        appendLine("- Keep menu labels short. The input may contain OCR noise; fix obvious OCR mistakes silently.")
        appendLine("- Output ONLY a JSON array of strings with exactly ${r.lines.size} items in the same order as the input. No explanations, no markdown.")
        if (r.glossary.isNotEmpty()) {
            appendLine("Glossary (always use these translations):")
            r.glossary.forEach { (k, v) -> appendLine("- $k => $v") }
        }
        if (r.context.isNotEmpty()) {
            appendLine("Recent lines of this game session, for context only (do not translate them again):")
            r.context.forEach { (s, t) -> appendLine("- $s => $t") }
        }
    }

    fun user(r: TranslationRequest): String =
        Json.encodeToString(ListSerializer(String.serializer()), r.lines)
}

object ResponseParser {
    private val json = Json { ignoreUnknownKeys = true; isLenient = true }

    fun parseArray(text: String, expected: Int): List<String> {
        var t = text.trim()
        if (t.startsWith("```")) t = t.removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        val start = t.indexOf('[')
        val end = t.lastIndexOf(']')
        if (start >= 0 && end > start) {
            try {
                val list = json.parseToJsonElement(t.substring(start, end + 1)).jsonArray
                    .map { (it as? JsonPrimitive)?.contentOrNull ?: it.toString() }
                if (list.size == expected) return list
            } catch (_: Exception) {
            }
        }
        if (expected == 1 && t.isNotEmpty()) return listOf(t)
        val lines = t.lines().map { it.trim() }.filter { it.isNotEmpty() }
        if (lines.size == expected) return lines
        throw TranslationException.BadResponse()
    }
}

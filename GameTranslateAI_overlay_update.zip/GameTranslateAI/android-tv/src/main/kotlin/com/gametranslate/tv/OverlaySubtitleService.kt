package com.gametranslate.tv

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

/**
 * نافذة ترجمة عائمة على مستوى Android. قد لا تظهر فوق بعض مداخل HDMI
 * لأن بعض الشركات تعرض HDMI في طبقة فيديو مستقلة عن نوافذ التطبيقات.
 */
class OverlaySubtitleService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var collectJob: Job? = null
    private var windowManager: WindowManager? = null
    private var subtitleView: TextView? = null

    override fun onCreate() {
        super.onCreate()
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        subtitleView = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 25f
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            gravity = Gravity.CENTER
            setPadding(28, 14, 28, 14)
            setBackgroundColor(0xB8000000.toInt())
            textDirection = TextView.TEXT_DIRECTION_LOCALE
            textAlignment = TextView.TEXT_ALIGNMENT_CENTER
        }
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            y = 58
        }
        runCatching { windowManager?.addView(subtitleView, params) }

        val app = application as? TvApp ?: return
        collectJob = scope.launch {
            app.container.engine.state.collectLatest { state ->
                subtitleView?.text = state.subtitle
                subtitleView?.visibility = if (state.subtitle.isBlank()) android.view.View.GONE else android.view.View.VISIBLE
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onDestroy() {
        collectJob?.cancel()
        runCatching { subtitleView?.let { windowManager?.removeView(it) } }
        subtitleView = null
        scope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}

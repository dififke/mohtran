package com.gametranslate.shared.translate

data class TranslationRequest(
    val lines: List<String>,
    val sourceLang: String,
    val targetLang: String,
    val context: List<Pair<String, String>> = emptyList(),
    val glossary: Map<String, String> = emptyMap()
)

interface TranslationProvider {
    val name: String
    /** false للوضع التجريبي كي لا تُخزَّن نتائجه في الـ Cache. */
    val cacheable: Boolean get() = true
    suspend fun translate(request: TranslationRequest): List<String>
}

sealed class TranslationException(message: String, cause: Throwable? = null) : Exception(message, cause) {
    class MissingKey(message: String = "لم يتم إدخال مفتاح API") : TranslationException(message)
    class InvalidKey(message: String = "مفتاح API غير صحيح أو غير مصرّح به") : TranslationException(message)
    class RateLimited(message: String = "تم تجاوز حد الطلبات، حاول بعد قليل") : TranslationException(message)
    class Network(message: String = "تعذر الاتصال بالشبكة أو بخادم الترجمة", cause: Throwable? = null) :
        TranslationException(message, cause)
    class BadResponse(message: String = "استجابة غير متوقعة من محرك الترجمة") : TranslationException(message)
}
